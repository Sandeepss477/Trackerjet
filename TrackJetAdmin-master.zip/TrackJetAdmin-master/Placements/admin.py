from django.contrib import admin

from AdminApp.admin import MasterAdmin
from Placements.models import Employer

class EmployerAdmin(MasterAdmin):
    list_display = ['company', 'contactperson', 'contactno']

    # fields = ('company',
    # 	('address','contactperson'),
    # 	('contactno','email'),
    # 	('website','isactive')
    # 	)


admin.site.register(Employer, EmployerAdmin)
