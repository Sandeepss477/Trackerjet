from django.db import models
from django.contrib import admin
from AdminApp.models import Master
from django.core.validators import RegexValidator

class Employer(Master):
    phone_regex = RegexValidator(regex=r'^\+?1?\d{9,10}$',
                  message="Phone number must be entered in the format: '9999999999'. Up to 10 digits allowed.")
    company = models.CharField(max_length=200, unique=True)
    address = models.CharField(max_length=500, blank=True)
    contactperson=models.CharField(max_length=200, blank=True, verbose_name="Contact Person")
    contactno = models.CharField(validators=[phone_regex], max_length=12,  verbose_name="Contact No.")
    email = models.EmailField(max_length=200, blank=True)
    website = models.CharField(max_length=200, blank=True)

    class Meta:
        verbose_name_plural = "Employer Details"

    def __str__(self):
        return self.company

