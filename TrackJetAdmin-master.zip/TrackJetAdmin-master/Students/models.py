from django import forms

from AdminApp.models import *
from django.contrib import admin
from django.contrib.admin import AdminSite
from django.contrib.auth.models import User
from django.contrib.admin.options import InlineModelAdmin
from django.db import models
from abc import ABC, abstractmethod
from django.core.validators import RegexValidator

from smart_selects.db_fields import ChainedForeignKey



GENDER_CHOICES = (
    (0, 'Male'),
    (1, 'Female'),
    (2, 'Not specified'),
)

# from django.conf import settings
# User = settings.AUTH_USER_MODEL

class Student(Master):
    import datetime
    YEAR_CHOICES = []
    for r in range((datetime.datetime.now().year - 15), (datetime.datetime.now().year + 5)):
        YEAR_CHOICES.append((r, r))

    phone_regex = RegexValidator(regex=r'^\+?1?\d{9,10}$',
                                 message="Phone number must be entered in the format: '9999999999'. Up to 10 digits allowed.")
    enquirysource= models.ForeignKey(EnquirySource, on_delete=models.CASCADE, verbose_name="Enquiry Source",null=False, blank=False, limit_choices_to={"isactive": True})
    dob = models.DateField(verbose_name="Date of Birth")
    studentname = models.CharField(max_length=200, verbose_name="Student",null=False, blank=False)
    gender = models.IntegerField(choices=GENDER_CHOICES, verbose_name="Gender", null=False, blank=False)
    phone = models.CharField(validators=[phone_regex], max_length=12, verbose_name="Phone",null=False, blank=False)
    email = models.EmailField(max_length=200, verbose_name="Email", null=False,blank=False)
    address = models.CharField(max_length=500, blank=True, verbose_name="Address")
    alternativeemail = models.EmailField(max_length=200, blank=True, verbose_name="Alternative Email")
    alternativeaddress = models.CharField(max_length=500, blank=True, verbose_name="Alternative Address")
    mobile = models.CharField(validators=[phone_regex], max_length=12, verbose_name="Mobile", blank=True)
    street = models.CharField(max_length=500, blank=True, verbose_name="Street")
    city = models.CharField(max_length=200, blank=True, verbose_name="City")
    state = models.ForeignKey(State, on_delete=models.CASCADE,null=False, blank=False, limit_choices_to={"isactive": True})
    district = ChainedForeignKey(District, chained_field="state", chained_model_field="state", show_all=False,
                                 auto_choose=True, sort=True, verbose_name="District", null=False, blank=False, limit_choices_to={"isactive": True})
    qualification = models.ForeignKey(Qualification, on_delete=models.CASCADE, verbose_name="Qualification", null=False, blank=False, limit_choices_to={"isactive": True})
    #course = models.CharField(max_length=200, unique=True, verbose_name="Course", null=False, blank=False)
    course = models.ForeignKey(Course, on_delete=models.CASCADE, verbose_name="Course",
                                      null=False, blank=False, limit_choices_to={"isactive": True})
    pincode = models.PositiveIntegerField(blank=True, null=True, verbose_name="Pincode")
    whatsapp = models.CharField(validators=[phone_regex], max_length=12, verbose_name="Whatsapp", null=False, blank=False)
    rollno = models.CharField(max_length=200, blank=False, verbose_name="Roll No")
    registrationno = models.CharField(max_length=200, blank=False, verbose_name="Registration No")
    collegename = models.CharField(max_length=200, blank=False, verbose_name="College Name")
    yearofpass = models.PositiveIntegerField(choices=YEAR_CHOICES, blank=False, null=False, verbose_name="Year of Pass")
    # default=datetime.datetime.now().year
    image = models.ImageField(upload_to='./media/images', verbose_name="Photo")

    isregistered = models.BooleanField(default=False,verbose_name="Registered")

    #isactive = models.BooleanField(default=True,verbose_name="Active")


    def __str__(self):
        return self.studentname

class StudentCallStatus(Transaction):
    student = models.ForeignKey(Student, on_delete=models.CASCADE, limit_choices_to={"isactive": True})
    studentcallstatus = models.ForeignKey(FollowUpStatus, on_delete=models.CASCADE, verbose_name="Student Call Status", limit_choices_to={"isactive": True})
    tostaff = models.ForeignKey(User, null=True, on_delete=models.CASCADE, related_name="tostaff", verbose_name="To Staff", limit_choices_to={"is_active": True})
    comments = models.CharField(max_length=800, verbose_name="Comments")
    nextfollowupdate = models.DateField(verbose_name="Next Follow-up Date")

    def __str__(self):
        return str(self.student) + " with status " + str(self.studentcallstatus)

class StudentCourseDetails(Master):
    LAPTOP_CHOICES = (
        ('Yes', 'Yes'),
        ('No', 'No'),
    )
    student = models.ForeignKey(Student, on_delete=models.CASCADE, limit_choices_to={"isactive": True})

    course = models.ForeignKey(Course, on_delete=models.CASCADE, verbose_name="Course",
                               null=True, blank=False, limit_choices_to={"isactive": True})
    coursedetails = models.CharField(max_length=800, blank=False, verbose_name="Course Details")
    batch = models.ForeignKey(Batch, on_delete=models.CASCADE, verbose_name="batch", blank=False,
                              related_name="studentcourses", limit_choices_to={"isactive": True})

    havelaptop = models.CharField(choices=LAPTOP_CHOICES, verbose_name="Does the student have Laptop?", null=False, blank=False, max_length=200)

    feestype = models.ForeignKey(MasterData, on_delete=models.CASCADE, verbose_name="Installment Type",
                                 limit_choices_to={"isactive": True, "type": 'Fee Type'}, related_name="FeeStudents")

    joindate = models.DateField(verbose_name="Joining Date")

    payregamount = models.BooleanField(verbose_name="Paying Registration Amount", blank=False)

    idproof = models.ForeignKey(MasterData, on_delete=models.CASCADE, verbose_name="ID Proof",
                                 limit_choices_to={"isactive": True, "type": 'IDProof Type'},  related_name="FeeTypeStudents")
    idproofno = models.CharField(max_length=200, verbose_name="ID Proof No.")
    iduploadfile = models.FileField(upload_to='./media/files', verbose_name="ID Upload")

    def __str__(self):
        return str(self.student) + " with course " + str(self.course)


class StudentFees(Transaction):
    student = models.ForeignKey(Student, on_delete=models.CASCADE, limit_choices_to={"isactive": True, "isregistered":True})
    studentcoursedetails = models.ForeignKey(StudentCourseDetails, on_delete=models.CASCADE, blank=True, null=True)
    #PaidDate = models.DateField(null=True)
    InstallmentDate = models.DateField()
    InstallmentAmount = models.IntegerField()
    BalanceAmount = models.IntegerField()
    taxper = models.IntegerField(verbose_name="Tax Per.", blank=True, null=True)

    def __str__(self):
        return f"Fees {self.InstallmentAmount} of {self.student} with installment date {self.InstallmentDate}"

class FeeReceipt (Transaction):
    paiddate = models.DateField(verbose_name="Paid Date")
    student = models.ForeignKey(Student, on_delete=models.CASCADE,
                                limit_choices_to={"isactive": True, "isregistered": True}, blank=True, null=True)
    studentcoursedetails = models.ForeignKey(StudentCourseDetails, on_delete=models.CASCADE, blank=True, null=True)
    studentfee = models.ForeignKey(StudentFees, on_delete=models.CASCADE, verbose_name="Total Fee", blank=True, null=True)
    paidamount = models.IntegerField(verbose_name="Paid Amount")
    balanceamount = models.IntegerField(verbose_name="Balance Amount")
    paidaccount = models.ForeignKey(MasterData, on_delete=models.CASCADE, verbose_name="Collected To which Account",limit_choices_to={"isactive":True,"type": 'PaymentAccount'}, related_name="FeeStudentsaccounttype", blank=False)
    taxper = models.IntegerField(verbose_name="Tax Per.")
    receiptno = models.IntegerField(verbose_name="Receipt No.", blank=True, null=True)
    mode = models.ForeignKey(MasterData, on_delete=models.CASCADE, verbose_name="Payment Mode", limit_choices_to={ "isactive": True, "type": 'PaymentMode'}, related_name="FeeStudentPaymentmode", blank=False)
    description = models.CharField(max_length=5000)
    receiptimage = models.ImageField(upload_to='./media/images', verbose_name="Receipt Image", blank=False)

    def __str__(self):
        return f"Fees of {self.studentfee.student} with installment date {self.studentfee.InstallmentDate}"


class StudentShort(Master):
    LAPTOP_CHOICES = (
        ('Yes', 'Yes'),
        ('No', 'No'),
    )
    phone_regex = RegexValidator(regex=r'^\+?1?\d{9,10}$',
                                 message="Phone number must be entered in the format: '9999999999'. Up to 10 digits allowed.")
    studentname = models.CharField(max_length=200, verbose_name="Student", null=False, blank=False)
    phone = models.CharField(validators=[phone_regex], max_length=12, verbose_name="Phone", null=False, blank=False)
    email = models.EmailField(max_length=200, verbose_name="Email", null=False, blank=False)
    batch = models.ForeignKey(Batch, on_delete=models.CASCADE, verbose_name="batch", blank=False,
                              related_name="studentbatches", limit_choices_to={"isactive": True})
    havelaptop = models.CharField(choices=LAPTOP_CHOICES, verbose_name="Does the student have Laptop?", null=False,
                                  blank=False, max_length=200)
    user = models.OneToOneField(User, on_delete=models.CASCADE, null=True, blank=True, related_name="studentusers", limit_choices_to={'groups__name': 'Student', 'is_active': True})

    class Meta:
        verbose_name_plural = "Students Info"
        verbose_name = "Student"

    def __str__(self):
        return self.studentname



# class MyInlineStudent(admin.TabularInline):
    #     model = Student
    #     fields = ['enquirysource', 'dob']









