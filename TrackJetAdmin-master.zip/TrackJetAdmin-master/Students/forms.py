from django import forms

# StudentAdminForm is created to solve the issue of selecting the student when follow up statuses are added..
class StudentCallStatusAdminForm(forms.ModelForm):

    @staticmethod
    def parse_filter_kwargs(**kwargs):
        if 'initial' in kwargs:
            if u'_changelist_filters' in kwargs['initial']:
                filters = kwargs['initial'][u'_changelist_filters']
                var, value = filters.split('=')
                if var == u'student':
                    return {'initial': {var: value}}
        return kwargs

    def __init__(self, *args, **kwargs):
        #print("hi")
        kwargs = self.parse_filter_kwargs(**kwargs)
        super(StudentCallStatusAdminForm, self).__init__(*args, **kwargs)

class StudentAdminForm(forms.ModelForm):
    dob = forms.DateTimeField(
        # input_formats=['%d-%m-%YT%H:%M'],
        widget=forms.DateInput(
            attrs={
                'type': 'date',
                'class': 'form-control'
            },
            #   format='%d-%m-%YT%H:%M'
        )
    )

class StudentCourseDetailsAdminForm(forms.ModelForm):
    joindate = forms.DateTimeField(
        # input_formats=['%d-%m-%YT%H:%M'],
        widget=forms.DateInput(
            attrs={
                'type': 'date',
                'class': 'form-control'
            },
            #   format='%d-%m-%YT%H:%M'

        ), label='Joining Date'
    )

    trainer = forms.CharField(required=False)
    start_date = forms.CharField(required=False)
    end_date = forms.CharField(required=False)

    # For checkbox validation of the field Paying Registration Amount..
    # def clean_payregamount(self):
    #     payregamount = self.cleaned_data.get('payregamount')
    #     if not payregamount:
    #         raise forms.ValidationError('This field is required')
    #     return payregamount

    @staticmethod
    def parse_filter_kwargs(**kwargs):
        if 'initial' in kwargs:
            if u'_changelist_filters' in kwargs['initial']:
                filters = kwargs['initial'][u'_changelist_filters']
                var, value = filters.split('=')
                if var == u'student':
                    return {'initial': {var: value}}
        return kwargs

    def __init__(self, *args, **kwargs):
        #print("hiform")
        kwargs = self.parse_filter_kwargs(**kwargs)
        super(StudentCourseDetailsAdminForm, self).__init__(*args, **kwargs)


class FeeReceiptForm(forms.ModelForm):
    paiddate = forms.DateTimeField(
        # input_formats=['%d-%m-%YT%H:%M'],
        widget=forms.DateInput(
            attrs={
                'type': 'date',
                'class': 'form-control',

            },
            #   format='%d-%m-%YT%H:%M'
        ), label='Paid Date'
    )

    description = forms.CharField(widget=forms.Textarea)

    #studentfee = forms.CharField(widget=forms.HiddenInput())

    receiptno = forms.IntegerField(widget=forms.TextInput(attrs={'readonly': 'readonly'}), required=False, label='Receipt No.')
    balanceamount = forms.CharField(widget=forms.TextInput(attrs={'readonly': 'readonly'}), label='Balance Amount')
    taxper = forms.CharField(widget=forms.TextInput(attrs={'readonly': 'readonly'}), label='Tax Per.')

    # def __init__(self, *args, **kwargs):
    #     print(kwargs['initial'])
    #     #kwargs = self.parse_filter_kwargs(**kwargs)
    #     super(FeeReceiptForm, self).__init__(*args, **kwargs)




