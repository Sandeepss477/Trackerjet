import os
from datetime import datetime
from io import BytesIO

from reportlab.lib import colors
from reportlab.pdfgen import canvas
from django.http import HttpResponse
from reportlab.lib.pagesizes import letter, landscape
from reportlab.lib.pagesizes import A4

from django.contrib.admin.views.decorators import staff_member_required
from django.shortcuts import render
from django.http import HttpResponse
import json

from reportlab.platypus import Table, TableStyle

from AdminApp.models import Batch, BatchTransfer, CourseFees, Company
from Students.models import Student, FeeReceipt
from TrackerJet_Admin.settings import BASE_DIR


# Create your views here.
@staff_member_required
def get_batchesAndFeetypesOfCourse(request):
    id = request.GET.get('id','')
    #result = list(Course.objects.filter(id=int(id)).UserTrainers_set.values())
    result = list(Batch.objects.filter(course=int(id),isactive=True,isclosed=False).values("id","batch"))
    feetypes = CourseFees.objects.filter(course=int(id)).filter(feestype__type="Fee Type").exclude(feestype__name__in=["Registration",]).values("feestype__id","feestype__name").distinct()
    #print(feetypes.query)
    result.append(list(feetypes))
    #result = list(CourseFees.objects.filter(course__course_id=int(id)).select_related("MasterData").values("id", "batch"))
    return HttpResponse(json.dumps(result), content_type="application/json")

@staff_member_required
def getTrainerAndDatesOfBatch(request):
    id = request.GET.get('id','')
    #result = list(Course.objects.filter(id=int(id)).UserTrainers_set.values())
    obj = BatchTransfer.objects.filter(batch_id=int(id)).order_by("-start_date")[0]

    #("trainer", "start_date", "end_date")
    result = list()
    result.append(obj.trainer)
    result.append(obj.start_date)
    result.append(obj.end_date)

    return HttpResponse(json.dumps(result, default=str), content_type="application/json")


def verify_phonenumber(request):
    global res
    from django.core.exceptions import MultipleObjectsReturned
    try:
        id = request.GET.get('id','')
        #result = list(Course.objects.filter(id=int(id)).UserTrainers_set.values())
        result = Student.objects.get(phone=id)
        #print(result)
    except Student.DoesNotExist:
        res = {"message": "Phone does not exist. Proceed"}
    except MultipleObjectsReturned:
        res = {"message": "Student with phone exists. Please add another."}
    except:
        res = {"message": "Something went wrong"}
    else:
        res = {"message": "Student with phone exists. Please add another."}

    return HttpResponse(json.dumps(res), content_type="application/json")

# https://medium.com/@saijalshakya/generating-pdf-with-reportlab-in-django-ee0235c2f133

def generate_feereceipt(request):
    try:
        id = request.GET.get('id', '')
        feereceipt = FeeReceipt.objects.get(id=id)
        qs = Company.objects.all()[:1]


        response = HttpResponse(content_type="application/pdf")
        d = datetime.today().strftime("%Y-%m-%d")
        response['Content-Disposition'] = f"inline; filename='{d}.pdf'"
        buffer = BytesIO()
        p = canvas.Canvas(buffer, pagesize=A4)

        # Data to print

        #address = "One Team Solutions EdTech Pvt Ltd,\r2nd Floor, Muttathottil Building,\rEdappally Toll\rEdappally-Pookkattupadi Road\rPin:682024\r+91 9946870803\raccounts@oneteamsolutions.co.in\roneteamsolutions.co.in\rGSTIN : 32AADCO8355L1Z5"
        #address1 = "One Team Solutions EdTech Pvt Ltd,"
        address1 = qs[0].company
        #address2 = "2nd Floor, Muttathottil Building,"
        address2 = qs[0].address1
        #address3 = "Edappally Toll,"
        address3 = qs[0].address2
        #address4 = "Edappally-Pookkattupadi Road,"
        address4 = qs[0].address3
        address5 = "Pin:682024,"
        #address5 = qs[0].address4
        #address6 = "+91 9946870803,"
        address6 = qs[0].phone
        #address7 = "accounts@oneteamsolutions.co.in,"
        address7 = qs[0].email
        #address8 = "oneteamsolutions.co.in,"
        address8 = qs[0].website
        address9 = "GSTIN : 32AADCO8355L1Z5,"

        # studentname = "Dileep G"
        studentname = feereceipt.student
        # course = "Software Testing"
        course = feereceipt.studentcoursedetails.course
        paiddate = ""
        receiptno = ""
        description = ""
        amount = 0
        amountinwords = ""
        authorizedby = ""

        # Start writing the PDF here
        fontsize = 15
        headingY = 800
        addressfirstY = headingY - 100
        addressdecrementY = 20
        p.setFont("Helvetica", fontsize, leading=None)
        p.setFillColorRGB(.29296875, 0.453125, 0.609375)
        p.drawString(260, headingY, "RECEIPT")
        #print(os.path.join(BASE_DIR, 'images/'))
        # from django.contrib.sites.shortcuts import get_current_site
        # url = get_current_site(request)
        # print(get_current_site(request))
        # print(request.path)
        #print(request.get_host())
        protocol = ""
        #print(request.is_secure())
        if request.is_secure():
            protocol = "https"
        else:
            protocol = "http"

        #imageurl = f"{protocol}://{request.get_host()}/images/images/cropped-Website-Logo-copy.png"
        imageurl = f"{protocol}://{request.get_host()}/images/{qs[0].Logo}"
        #print(imageurl)
        #imageurl = "http://localhost:8000/images/images/cropped-Website-Logo-copy.png"
        p.drawImage(imageurl, 10, headingY - 70, width=200, height=50, mask="auto")

        p.drawString(10, addressfirstY, f"{address1}")
        p.drawString(10, (addressfirstY - addressdecrementY), f"{address2}")
        p.drawString(10, (addressfirstY - (addressdecrementY * 2)), f"{address3}")
        p.drawString(10, (addressfirstY - (addressdecrementY * 3)), f"{address4}")
        p.drawString(10, (addressfirstY - (addressdecrementY * 4)), f"{address5}")
        p.drawString(10, (addressfirstY - (addressdecrementY * 5)), f"{address6}")
        p.drawString(10, (addressfirstY - (addressdecrementY * 6)), f"{address7}")
        p.drawString(10, (addressfirstY - (addressdecrementY * 7)), f"{address8}")
        p.drawString(10, (addressfirstY - (addressdecrementY * 8)), f"{address9}")

        studentY = (addressfirstY - (addressdecrementY * 8)) - 50

        p.drawString(10, studentY, f"Student Name : {studentname}")
        p.drawString(10, studentY - addressdecrementY, f"Course : {course}")

        # description = "UPI ID 310709199682__ONLINE TRASACTION__SECOND INSTALLMENT FEES"
        # amount = "10000.00"
        description = feereceipt.description
        amount = feereceipt.paidamount

        #Table
        data = [['Description', 'Amount'],
                [description, amount],
                ["Total", amount],
                ]
        t = Table(data, style=[('GRID',(0,0),(-1,-1),1,colors.black),
                    ], rowHeights=30)
        t.setStyle(TableStyle([('FONTNAME', (0, 0), (1, 0), "Helvetica-Bold"),
                               ('FONTNAME', (0, 2), (1, 2), "Helvetica-Bold"),
                               ('FONTSIZE', (0,0), (-1,-1), 10),
                               ('TEXTCOLOR', (0, 0), (-1, -1), (.29296875, 0.453125, 0.609375))]))
        width = 400
        height = 100
        x = 10
        y = studentY - (addressdecrementY * 6)
        t.wrapOn(p, width, height)
        t.drawOn(p, x, y)




        p.setTitle(f"Fee Receipt")
        p.showPage()
        p.save()

        pdf = buffer.getvalue()
        buffer.close()
        response.write(pdf)
        return response





    except:
        res = {"message": "Something went wrong"}

def generate_pdf(request):
    response = HttpResponse(content_type="application/pdf")
    d = datetime.today().strftime("%Y-%m-%d")
    response['Content-Disposition'] = f"inline; filename='{d}.pdf'"
    buffer = BytesIO()
    p = canvas.Canvas(buffer, pagesize=A4)

    #Data to print
    data = {
        "Posts": [{"title": "Python", "views": 500}, {"title": "JavaScript", "views": 500}],
        "Videos": [{"title": "Python Programming", "likes": 500}],
        "Blogs": [{"name": "Report Lab", "likes": 500, "claps": 500}],
    }

    #Start writing the PDF here
    p.setFont("Helvetica", 15, leading=None)
    p.setFillColorRGB(.29296875, 0.453125, 0.609375)
    p.drawString(260, 800, "My Website")
    p.line(0, 780, 1000, 780)
    p.line(0, 778, 1000, 778)
    x1 = 20
    y1 = 750
    #Render Data
    for k, v in data.items():
        p.setFont("Helvetica", 15, leading=None)
        p.drawString(x1, y1-12, f"{k}")
        for value in v:
            for key, val in value.items():
                p.setFont("Helvetica", 10, leading=None)
                p.drawString(x1, y1 - 20, f"{key} - {val}")
                y1 = y1 - 60
    p.setTitle(f"Report on {d}")
    p.showPage()
    p.save()

    pdf = buffer.getvalue()
    buffer.close()
    response.write(pdf)
    return response




