from datetime import timedelta

from django.contrib import admin
from django.core.exceptions import MultipleObjectsReturned
from django.db import IntegrityError
from django.db.models import Count
from django.http import HttpResponseRedirect
from import_export.admin import ImportExportModelAdmin
from django.contrib.auth.models import User, Group

from AdminApp.admin import MasterAdmin, TransactionAdmin

from AdminApp.models import District, State, EnquirySource, Qualification, Course, CourseFees, MasterData, UserProfile
from Students.models import Student, StudentCallStatus, StudentCourseDetails, StudentFees, FeeReceipt, StudentShort
from Students.forms import StudentAdminForm, StudentCourseDetailsAdminForm, FeeReceiptForm
from urllib.parse import urlencode, parse_qsl
from django.urls import reverse
from django.utils.html import format_html
from django import forms
from Students.forms import StudentCallStatusAdminForm
from Students.resources import StudentShortResource


# Register your models here.


class StudentAdmin(MasterAdmin):
    list_display = ['studentname', 'team_member', 'phone', 'enquirysource', 'course', 'view_followup_link','view_course_link','view_fees_link','isregistered', 'isactive']
    search_fields = ['studentname__startswith', 'course__contains']
    list_filter = ("isregistered", "course", "enquirysource", "created_date")
    #search_form_template = "test.html"
    form = StudentAdminForm
    # inlines = (StudentCallStatusInline,)
    exclude = ['isregistered', 'created_user']

    readonly_fields = ('verifyphone',)

    fieldsets = (
        ('General', {'fields': ('enquirysource',)}),
        ('Phone Verification', {'fields': (('phone', 'verifyphone'))}),
        ('Personal Info', {'fields': (
        ('studentname', 'gender'), ('email', 'alternativeemail'), ('address', 'alternativeaddress'), ('dob', 'mobile'),
        ('street', 'city'), ('state', 'district'), ('pincode', 'whatsapp'))}),
        ('Academic Info', {'fields': (('collegename', 'yearofpass'), ('qualification', ), ('rollno', 'registrationno'))}),
        ('Course Info', {'fields': ('course',)}),
        ('Photo', {'fields': ('image', )}),
    )

    def save_model(self, request, obj, form, change):
        if change == False:
            #global res
            try:
                phoneno = obj.phone
                # result = list(Course.objects.filter(id=int(id)).UserTrainers_set.values())
                result = Student.objects.get(phone=phoneno)
            except Student.DoesNotExist:
                #res = {"message": "Phone does not exist. Proceed"}
                #self.message_user(request, "Candidate has been registered")
                super().save_model(request, obj, form, change)
            except MultipleObjectsReturned:
                self.message_user(request, "Student with phone exists. Please add another.")
            except:
                self.message_user(request, "Something went wrong")
            else:
                self.message_user(request, "Student with phone exists. Please add another.")
        else:
            super().save_model(request, obj, form, change)

    def verifyphone(self, obj):
        return format_html('<a href="#" onclick="verifyPhoneNumber()">Verify Phone Number</a>')

        # url = (
        #         reverse("admin:Students_studentcallstatus_changelist")
        #         + "?"
        #         + urlencode({"student": f"{obj.id}"})
        # )
        # print(url)
        #return format_html('<a href="{}">Go</a>', url)


    verifyphone.allow_tags = True
    verifyphone.short_description = ""

    change_form_template = "studentenquiry_form.html"

    # To hide the inline model on edit
    def get_inlines(self, request, obj=None):
        # print(obj)
        if obj:
            return ()
        else:
            return (StudentCallStatusInline,)

    def get_form(self, request, obj=None, **kwargs):
        form = super().get_form(request, obj, **kwargs)
        fieldlist = ['course', 'enquirysource', 'qualification', 'state', 'district']
        for fld in fieldlist:
            form.base_fields[fld].widget.can_change_related = False
            form.base_fields[fld].widget.can_add_related = False
            form.base_fields[fld].widget.can_view_related = False
        return form

    # Code to register a student
    def response_change(self, request, obj):
        if "_register" in request.POST:
            # matching_names_except_this = self.get_queryset(request).filter(name=obj.name).exclude(pk=obj.id)
            # matching_names_except_this.delete()
            obj.isregistered = True
            obj.save()
            # print("kkk")
            # print(obj.pk)
            # print(obj.id)
            #request.session["student_id"] = obj.pk
            self.message_user(request, "Candidate has been registered")
            return HttpResponseRedirect(f"/admin/Students/studentcoursedetails/add/?student={obj.pk}")
        #return super().response_change(request, obj)

    # To filter out the inactive states & districts
    # def formfield_for_foreignkey(self, db_field, request, **kwargs):
    #     # print(db_field.name)
    #     if db_field.name == "district":
    #         kwargs["queryset"] = District.objects.filter(isactive=True)
    #     elif db_field.name == "state":
    #         kwargs["queryset"] = State.objects.filter(isactive=True)
    #     elif db_field.name == "enquirysource":
    #         kwargs["queryset"] = EnquirySource.objects.filter(isactive=True)
    #     elif db_field.name == "qualification":
    #         kwargs["queryset"] = Qualification.objects.filter(isactive=True)
    #     elif db_field.name == "course":
    #         kwargs["queryset"] = Course.objects.filter(isactive=True)
    #
    #     return super().formfield_for_foreignkey(db_field, request, **kwargs)

    # def queryset(self, request):
    #     qs = super(StudentAdmin, self).queryset(request)
    #     print("Hello")
    #     if request.user.is_superuser:
    #         print("yes")
    #         return qs.filter(request.user.username == "RohiniOneTeam")
    #     print("no")
    #     return qs.filter(request.user.username == "admin")

    def get_queryset(self, request):
        queryset = super().get_queryset(request)
        # print("Hello")
        # queryset = queryset.filter(created_user__username__exact= "admin")
        current_user = request.user
        print(current_user.id)
        queryset = queryset.filter(created_user__in=[2, 1])

        queryset = queryset.annotate(
            _studentcallstatus_count=Count("studentcallstatus"),

        )
        return queryset

    def team_member(self, obj):
        # print("Team")
        if obj._studentcallstatus_count > 0:
            #print(obj.studentcallstatus_set.all().order_by('-created_date')[:1][0].tostaff)
            return obj.studentcallstatus_set.all().order_by('-created_date')[:1][0].tostaff
        else:
            return ""

    def view_followup_link(self, obj):
        # count = obj.district_set.count()
        url = (
                reverse("admin:Students_studentcallstatus_changelist")
                + "?"
                + urlencode({"student": f"{obj.id}"})
        )
        # print(url)
        return format_html('<a href="{}">Go</a>', url)

    view_followup_link.allow_tags = True
    view_followup_link.short_description = "Follow Up"

    def view_fees_link(self, obj):
        # count = obj.district_set.count()
        #is_registered = Student.objects.get(id=obj.pk).isregistered
        if(obj.isregistered):
            url = (
                reverse("admin:Students_studentfees_changelist")
                + "?"
                + urlencode({"student": f"{obj.id}"})
            )
        # print(url)
            return format_html('<a href="{}">Go</a>', url)
        else:
            return " "


    view_fees_link.allow_tags = True
    view_fees_link.short_description = "Fees"

    def view_course_link(self, obj):
        # count = obj.district_set.count()
        #is_registered = Student.objects.get(id=obj.pk).isregistered
        if(obj.isregistered):
            url = (
                reverse("admin:Students_studentcoursedetails_changelist")
                + "?"
                + urlencode({"student": f"{obj.id}"})
            )
        # print(url)
            return format_html('<a href="{}">Go</a>', url)
        else:
            return " "


    view_course_link.allow_tags = True
    view_course_link.short_description = "Courses"


#class used for configuring which all fields need to be listed..
class StudentCallStatusAdmin(TransactionAdmin):
    list_display = ['studentcallstatus','nextfollowupdate', 'tostaff']
    #exclude = ['student', 'created_user']



    form = StudentCallStatusAdminForm

    def has_module_permission(self, request):
        return False

    def add_view(self, request, form_url='', extra_context=None):

        #global batch_id
        student_id = request.GET.get('_changelist_filters')
        #print(student_id)
        if student_id != None:
            student_id = student_id.split("=")[1]
            #print(batch_id)
            studentname = Student.objects.get(id=student_id)

        extra_context = {'title': f'Add followup status of {studentname}.'}

        return super(StudentCallStatusAdmin, self).add_view(request, form_url, extra_context)

    # Code to change the title in change list
    def changelist_view(self, request, extra_context=None):
        studentid = request.GET.get("student")
        if (studentid):
            studentname = Student.objects.get(id=studentid)
            # print(coursename)
            extra_context = {'title': f'FollowUp status of {studentname}.'}

        return super(StudentCallStatusAdmin, self).changelist_view(request, extra_context=extra_context)


    def get_form(self, request, obj=None, **kwargs):
        form = super().get_form(request, obj, **kwargs)
        fieldlist = ['studentcallstatus', 'tostaff', 'student']
        for fld in fieldlist:
            form.base_fields[fld].widget.can_change_related = False
            form.base_fields[fld].widget.can_add_related = False
            form.base_fields[fld].widget.can_view_related = False
        return form

# https://stackoverflow.com/questions/877723/inline-form-validation-in-django
class StudentCallStatusInlineFormset(forms.models.BaseInlineFormSet):
    def clean(self):
        # get forms that actually have valid data
        count = 0
        for form in self.forms:
            try:
                if form.cleaned_data:
                    count += 1
            except AttributeError:
                # annoyingly, if a subform is invalid Django explicity raises
                # an AttributeError for cleaned_data
                pass
        if count < 1:
            raise forms.ValidationError('You must have at least one call status')

# https://medium.com/nerd-for-tech/from-zero-to-hero-django-admin-model-relations-part5-c4c60c6d57a7
# Added an Inline class for adding Student Call Status when a student is added

class StudentCallStatusInline(admin.StackedInline):
    formset = StudentCallStatusInlineFormset
    model = StudentCallStatus
    fields = ('studentcallstatus', 'nextfollowupdate', 'tostaff', 'comments')
    #readonly_fields = ('added_date',)
    extra = 1 # only one record should be listed for adding initially
    max_num = 1 # the user should not be able to add more than one record
    can_delete = False # remove the delete option
    verbose_name = "Student Call Status"
    #verbose_name_plural = "Student Call Statuses"
    def __str__(self):
        return str(self.studentcallstatus)


class StudentCourseDetailsAdmin(MasterAdmin):
    list_display = ['course', 'view_student_link',  'batch', 'joindate', 'feestype', 'view_fees_link']
    #list_display_links = ('course', 'student')

    #list_filter = ("course",)
    #search_fields = ("course__course__startswith",)
    #readonly_fields = ("feestype",)
    #hidden_menu = True
    form = StudentCourseDetailsAdminForm
    add_form_template = "studentcoursedetails_form.html"
    change_form_template = "studentcoursedetails_form.html"

    fieldsets = (
        (None, {'fields': ('student',)}),
        #('Course Details', {'fields': (('course', 'coursedetails'))}),
        ('Course Details', {'fields': (
            ('course', 'coursedetails'), ('batch', 'trainer'), ('start_date', 'end_date'),
            ('havelaptop', 'feestype'),
            ('joindate', 'payregamount'),)}),
        ('ID Proof Details', {'fields': (('idproof', 'idproofno'), ('iduploadfile',))}),

    )

    def view_student_link(self, obj):
        return format_html('<a href="/admin/Students/student/{}/change/">{}</a>', obj.student.id, obj.student)

    view_student_link.allow_tags = True
    view_student_link.short_description = "Student"

    def view_fees_link(self, obj):

        url = (
                reverse("admin:Students_studentfees_changelist")
                + "?"
                + urlencode({"studentcoursedetails": f"{obj.id}"})
            )
        return format_html('<a href="{}">Go</a>', url)

    view_fees_link.allow_tags = True
    view_fees_link.short_description = "Fees"





    def has_module_permission(self, request):
        return False

    def save_model(self, request, obj, form, change):

        super().save_model(request, obj, form, change)


        if change == False:

            regamount = 0

            if obj.payregamount == True:

                feetypeid = MasterData.objects.get(isactive=True, type='Fee Type', name='Registration').id

                qs = CourseFees.objects.filter(feestype__id=feetypeid, course__id=obj.course.id).order_by(
                    'installment_period')
                # print(qs.query)

                for q in qs:
                    # print(q.amount)
                    # print(q.installment_period)
                    fee = StudentFees()
                    fee.InstallmentAmount = q.amount
                    fee.student = obj.student
                    fee.studentcoursedetails = obj
                    # Old code to calculate installment date based on batch start date
                    # fee.InstallmentDate = obj.batch.start_date + timedelta(days=q.installment_period)
                    # New code to calculate installment date based on student's joined date
                    fee.InstallmentDate = obj.joindate + timedelta(days=q.installment_period)
                    #If student Joining Date is less than Batch Start Date, then Fee installment dates should be calculated based on Batch Start Date.

                    #----------------------------------------------------------------------
                    fee.created_user = request.user
                    fee.BalanceAmount = q.amount
                    fee.taxper = q.tax
                    fee.save()
            else:
                feetypeid = MasterData.objects.get(isactive=True, type='Fee Type', name='Registration').id

                regamount = CourseFees.objects.get(feestype__id=feetypeid, course__id=obj.course.id).amount


            qs = CourseFees.objects.filter(feestype__id=obj.feestype.id, course__id=obj.course.id).order_by('installment_period')
            #print(qs.query)
            feecount = 0

            for q in qs:
                feecount = feecount + 1
                # print(q.amount)
                # print(q.installment_period)
                fee = StudentFees()
                amount = q.amount
                # For add registration amount to first installment amount
                if feecount == 1:
                    amount = amount + regamount

                fee.InstallmentAmount = amount
                fee.student = obj.student
                fee.studentcoursedetails = obj
                # Old code to calculate installment date based on batch start date
                #fee.InstallmentDate = obj.batch.start_date + timedelta(days=q.installment_period)
                # New code to calculate installment date based on student's joined date
                fee.InstallmentDate = obj.joindate + timedelta(days=q.installment_period)
                fee.created_user = request.user
                fee.BalanceAmount = amount
                fee.taxper = q.tax
                fee.save()
        else:
            pass


        return HttpResponseRedirect(f"/admin/Students/studentcoursedetails/?student={obj.student.pk}")



    # Code to change the title in change list
    def changelist_view(self, request, extra_context=None):
        studentid = request.GET.get("student")
        if(studentid):
            #coursename = Course.objects.filter(id=courseid).values()[0].get("course")
            studentname = Student.objects.get(id=studentid)
            #print(coursename)
            extra_context = {'title': f'Course & Batch details of {studentname}.'}

        return super(StudentCourseDetailsAdmin, self).changelist_view(request, extra_context=extra_context)

    def get_form(self, request, obj=None, **kwargs):
        form = super().get_form(request, obj, **kwargs)
        fieldlist = ['student','course', 'feestype', 'batch', 'idproof']
        for fld in fieldlist:
            form.base_fields[fld].widget.can_change_related = False
            form.base_fields[fld].widget.can_add_related = False
            form.base_fields[fld].widget.can_view_related = False

        #print(request.GET.get('_changelist_filters'))

        if(request.GET.get('_changelist_filters') != None):
            query_params = dict(parse_qsl(request.GET['_changelist_filters']))
            #print(query_params.get('student'))
            student_id = query_params.get('student')
        else:

            student_id = request.GET.get('student')
            #print(student_id)

        if student_id != None:
            student = Student.objects.get(id=student_id)
            form.base_fields['course'].initial = student.course.pk


        # if(obj == None):
        #     form.base_fields['course'].initial = student.course.pk
        #

        return form


    # def formfield_for_foreignkey(self, db_field, request, **kwargs):
    #     if db_field.name == "feestype":
    #         print("dd")
    #         kwargs["queryset"] = MasterData.objects.exclude(name__in=["Registration",])
    #     return super().formfield_for_foreignkey(db_field, request, **kwargs)
class StudentFeesAdmin(TransactionAdmin):
    list_display = ['InstallmentDate', 'InstallmentAmount', 'BalanceAmount', 'view_pay_link']
    list_display_links = None
    ordering = ('InstallmentDate', 'created_date')
    readonly_fields = ('InstallmentDate','BalanceAmount',)

    change_list_template = "studentfees_changelist.html"
    add_form_template = "admin/common_form.html"
    change_form_template = "admin/common_form.html"

    def view_pay_link(self, obj):
        #return u'<a href="/student/%s/">%s</a>' % (obj.student, obj.student)
        if(obj.BalanceAmount > 0):
            return format_html('<a href="/admin/Students/feereceipt/add/?fee={}">Pay</a>', obj.id)
        else:
            return ""

    view_pay_link.allow_tags = True
    view_pay_link.short_description = "Payment"



    def has_module_permission(self, request):
        return False

    def has_add_permission(self, request):
        return False

    def get_form(self, request, obj=None, **kwargs):
        form = super().get_form(request, obj, **kwargs)
        fieldlist = ['student']
        for fld in fieldlist:
            form.base_fields[fld].widget.can_change_related = False
            form.base_fields[fld].widget.can_add_related = False
            form.base_fields[fld].widget.can_view_related = False
        return form

        # Code to change the title in change list
    # Code to change the title in change list
    def changelist_view(self, request, extra_context=None):
        studentid = request.GET.get("student")
        if(studentid):
            #coursename = Course.objects.filter(id=courseid).values()[0].get("course")
            studentname = Student.objects.get(id=studentid)
            #print(coursename)
            extra_context = {'title': f'Fees details of {studentname}.'}

        return super(StudentFeesAdmin, self).changelist_view(request, extra_context=extra_context)

    def save_model(self, request, obj, form, change):


        # if(obj.BalanceAmount > obj.InstallmentAmount):
        #     fee = StudentFees()
        #     fee.PaidDate = obj.PaidDate
        #     fee.InstallmentAmount = obj.InstallmentAmount
        #     fee.student = obj.student
        #     fee.InstallmentDate = obj.InstallmentDate
        #     fee.created_user = request.user
        #     fee.BalanceAmount = obj.BalanceAmount - obj.InstallmentAmount
        #     fee.save()
        #
        # obj.BalanceAmount = obj.BalanceAmount - obj.InstallmentAmount
        super().save_model(request, obj, form, change)

        # print("hi")


    def response_change(self, request, obj, post_url_continue=None):
        """
        This makes the response go to the newly created
        model's change page without using reverse
        """
        return HttpResponseRedirect(f"/admin/Students/studentfees/?student={obj.student.id}")
    def response_add(self, request, obj, post_url_continue=None):
        """
        This makes the response go to the newly created
        model's change page without using reverse
        """
        return HttpResponseRedirect(f"/admin/Students/studentfees/?student={obj.student.id}")


class FeeReceiptAdmin(TransactionAdmin):
    list_display = ['paiddate', 'paidamount', 'receiptno', 'mode', 'description', 'paidaccount', 'view_print_link']
    #list_display_links = None
    ordering = ('created_date',)
    #readonly_fields = ('taxper', 'receiptno', 'balanceamount',)
    #exclude = ['studentfee', 'created_user']
    form = FeeReceiptForm

    fieldsets = (
        (None, {'fields': (
            ('paiddate', 'receiptno'),
            ('balanceamount', 'paidamount'),
            ('paidaccount', 'taxper'),
            ('mode', 'description'),
            ('receiptimage', ),

        )}),
    )

    def view_print_link(self, obj):
        return format_html('<a href="/admin/Students/generate_feereceipt/?id={}">Go</a>', obj.id)
        # if(obj.BalanceAmount > 0):
        #     return format_html('<a href="/admin/Students/feereceipt/add/?fee={}">Pay</a>', obj.id)
        # else:
        #     return ""

    view_print_link.allow_tags = True
    view_print_link.short_description = "Print"


    def has_module_permission(self, request):
        return False

    def has_add_permission(self, request):
        return ("add" in request.path)



    def changelist_view(self, request, extra_context=None):
        studentid = request.GET.get("student")
        studentcoursedetailsid = request.GET.get("studentcoursedetails")
        if(studentid):
            studentname = Student.objects.get(id=studentid)
            extra_context = {'title': f'Fee Receipts of {studentname}.'}
        elif(studentcoursedetailsid):
            studentcourse = StudentCourseDetails.objects.get(id=studentcoursedetailsid)
            extra_context = {'title': f'Fee Receipts of {studentcourse.student} of course {studentcourse.course}.'}

        return super(FeeReceiptAdmin, self).changelist_view(request, extra_context=extra_context)


    def save_model(self, request, obj, form, change):
        studentfee = StudentFees.objects.get(pk=request.GET.get('fee'))
        obj.studentfee = studentfee
        obj.studentcoursedetails = studentfee.studentcoursedetails
        obj.student = studentfee.student
        balanceamount = obj.balanceamount - obj.paidamount
        #obj.balanceamount = balanceamount
        studentfee.BalanceAmount = balanceamount
        studentfee.save()
        receiptno = MasterData.objects.get(type="Fee_Receipt_Start_No").value
        print(receiptno)
        #if (FeeReceipt.objects.count() == 0):
        obj.receiptno = int(receiptno) + FeeReceipt.objects.count()

        super().save_model(request, obj, form, change)







    def get_form(self, request, obj=None, **kwargs):
        form = super().get_form(request, obj, **kwargs)
        fieldlist = ['paidaccount', 'mode']
        for fld in fieldlist:
            form.base_fields[fld].widget.can_change_related = False
            form.base_fields[fld].widget.can_add_related = False
            form.base_fields[fld].widget.can_view_related = False
        fee_id = request.GET.get('fee')
        if ((fee_id != None) and (obj == None)):
            studentfee = StudentFees.objects.get(id=fee_id)
            form.base_fields['balanceamount'].initial = studentfee.BalanceAmount
            form.base_fields['taxper'].initial = studentfee.taxper

        return form


class StudentShortAdmin(MasterAdmin, ImportExportModelAdmin):
    list_display = ['studentname', 'batch', 'phone', 'email', 'havelaptop']
    resource_class = StudentShortResource
    # exclude = ['user']

    def get_form(self, request, obj=None, **kwargs):
        self.exclude.append('user')
        form = super().get_form(request, obj, **kwargs)
        form.base_fields['batch'].widget.can_change_related = False
        form.base_fields['batch'].widget.can_add_related = False
        form.base_fields['batch'].widget.can_view_related = False
        return form

    def save_model(self, request, obj, form, change):

        if(change == False):
            from AdminApp.common import create_student_user
            user = create_student_user(obj.studentname, obj.email, obj.batch.branch, obj.phone)
            obj.user = user




        super().save_model(request, obj, form, change)









admin.site.register(Student, StudentAdmin)
admin.site.register(StudentCallStatus, StudentCallStatusAdmin)
admin.site.register(StudentCourseDetails, StudentCourseDetailsAdmin)
admin.site.register(StudentFees, StudentFeesAdmin)
admin.site.register(FeeReceipt, FeeReceiptAdmin)
admin.site.register(StudentShort, StudentShortAdmin)