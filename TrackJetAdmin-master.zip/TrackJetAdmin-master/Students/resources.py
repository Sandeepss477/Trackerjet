from import_export import resources, fields
from import_export.fields import Field
from import_export.widgets import ForeignKeyWidget

from AdminApp.models import Batch
from Students.models import StudentShort


def my_model_on_save_action(instance):
    pass


class StudentShortResource(resources.ModelResource):
    #id = Field(attribute="id", column_name="ID")
    studentname = Field(attribute="studentname", column_name="Student Name")
    phone = Field(attribute="phone", column_name="Phone")
    email = Field(attribute="email", column_name="Email")
    # batch = Field(attribute="batch__batch", column_name="Batch")
    batch = fields.Field(
        column_name='Batch',
        attribute='batch',
        widget=ForeignKeyWidget(Batch, field='batch'))
    havelaptop = Field(attribute="havelaptop", column_name="Have Laptop")

    # def after_save_instance(
    #         self, instance: StudentShort, using_transactions: bool, dry_run: bool,
    # ):
    #     super().after_save_instance(instance, using_transactions, dry_run)
    #     if dry_run is False:
    #         my_model_on_save_action(instance)

    def after_import_instance(self, instance, new, **kwargs):
        #print("AfterImport")
        instance.created_user = kwargs['user']

    def before_save_instance(self, instance, using_transactions, dry_run):
        # print(dry_run)
        # print(type(instance))
        if (dry_run == False):
            # print(instance.id)
            if (instance.id is None):
                # print("HI")
                branch = Batch.objects.get(id=instance.batch.id).branch
                from AdminApp.common import create_student_user
                user = create_student_user(instance.studentname, instance.email, branch, instance.phone)
                # print(StudentShort.objects.latest('id').query)
                id = StudentShort.objects.latest('id').id

                instance.id=id+1
                #instance.created_user = kwargs['user']
                instance.user = user
                super().before_save_instance(instance, using_transactions, dry_run)

                # print(f" {instance.studentname} - {instance.phone} - {instance.email} - {instance.batch}")


        #instance.publisher_id = self.publisher_id




    # def after_import_row(self, row, row_result, **kwargs):
    #     # print(row)
    #     studentname = row.get('Student Name')
    #     phone = row.get('Phone')
    #     email = row.get('Email')
    #     batch = row.get('Batch')
    #
    #     branch = Batch.objects.get(batch=batch).branch.id
    #     #print(Batch.objects.filter(batch=batch).query)
    #     #print(f" {studentname} - {phone} - {email} - {batch} - {branch}")
    #     from AdminApp.common import create_student_user
    #     #
    #     user = create_student_user(studentname, email, branch, phone)
    #
    #
    #     # (cat, _created) = Category.objects.get_or_create(name=name)
    #     # row['category'] = cat.id

    # def get_queryset(self):
    #     #print("Export")
    #     return self._meta.model.objects.order_by('studentname')

    class Meta:
        model = StudentShort
        import_id_fields = ('phone',)
        # PROCESS_WITHOUT_SHOW_CONFIRM_FORM = True
        fields = ('studentname', 'phone', 'email', 'batch', 'havelaptop')
        # skip_unchanged = True
        # report_skipped = False
        export_order = ('studentname', 'phone', 'email', 'batch', 'havelaptop')
