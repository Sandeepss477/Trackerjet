
from django.urls import path, re_path, include

from Students import views

urlpatterns = [
    #re_path(r'^/get_trainersOfCourse/$', views.get_trainersOfCourse)
    #path(r'^index/$', views.index, name='index'),
    #path('index/', views.index, name='index'),
    path('get_batchesAndFeetypesOfCourse/', views.get_batchesAndFeetypesOfCourse),
    path('verify_phonenumber/', views.verify_phonenumber),
    path('getTrainerAndDatesOfBatch/', views.getTrainerAndDatesOfBatch),
    path('generate-pdf/', views.generate_pdf),
    path('generate_feereceipt/', views.generate_feereceipt),
]
