from django.apps import AppConfig


class ResourceallocationConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'ResourceAllocation'
