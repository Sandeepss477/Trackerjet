from django import forms

from ResourceAllocation.models import ComputerAllocation


class ComputerAllocationForm(forms.ModelForm):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # self.fields['student'].disabled = True
        self.fields['student'].widget.can_change_related = False
        self.fields['student'].queryset = ComputerAllocation.objects.none()

    class Meta:
        model = ComputerAllocation
        fields = '__all__'
