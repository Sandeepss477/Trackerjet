from django.contrib import admin

from AdminApp.admin import MasterAdmin, TransactionAdmin
from ResourceAllocation.forms import ComputerAllocationForm
from ResourceAllocation.models import ComputerBrand, Room, System, RoomAllocation, ComputerAllocation


# Register your models here.

class ComputerBrandAdmin(MasterAdmin):
    list_display = ('name',)

class RoomAdmin(MasterAdmin):
    list_display = ('name', 'branch', 'floor', 'type', 'noofseats')

class SystemAdmin(MasterAdmin):
    list_display = ('branch', 'code', 'category', 'rentalorown', 'brand', 'serialno', 'person')

class RoomAllocationAdmin(TransactionAdmin):
    list_display = ('branch', 'batch', 'reservation_type', 'person', 'from_date', 'to_date', 'room', 'purpose')

class ComputerAllocationAdmin(TransactionAdmin):
    list_display = ('branch', 'batch', 'student', 'computer', 'from_date', 'to_date')
    form = ComputerAllocationForm

    # def get_queryset(self, request):
    #     print("haa")
    #     queryset = super().get_queryset(request)
    #     queryset = []
    #     return queryset


admin.site.register(ComputerBrand, ComputerBrandAdmin)
admin.site.register(Room, RoomAdmin)
admin.site.register(System, SystemAdmin)
admin.site.register(RoomAllocation, RoomAllocationAdmin)
admin.site.register(ComputerAllocation, ComputerAllocationAdmin)
