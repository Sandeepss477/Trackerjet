from django.contrib.auth.models import User
from django.db import models
from django.db.models import Q

from AdminApp.models import MasterData, Master, Branch, Batch, Transaction
from Students.models import StudentShort


# Create your models here.
class ComputerBrand(Master):  # Renamed to ComputerBrand
    name = models.CharField(max_length=100, blank=False)

    def __str__(self):
        return self.name


class Room(Master):
    # floor_CHOICES = (
    #     ('ground', 'Ground'),
    #     ('first', 'First'),
    #     ('second', 'Second'),
    # )
    type_CHOICES = (
        ('classroom', 'Classroom'),
        ('conference', 'Conference'),
    )

    branch = models.ForeignKey(Branch, on_delete=models.CASCADE, limit_choices_to={"isactive": True})
    name = models.CharField(max_length=100, blank=False)
    floor = models.ForeignKey(MasterData, on_delete=models.CASCADE,
                                 limit_choices_to={"isactive": True, "type": 'Floor'})
    # floor = models.CharField(choices=floor_CHOICES, verbose_name="Floor", null=False,
    #                          blank=False, max_length=200)
    type = models.CharField(choices=type_CHOICES, verbose_name="Type", null=False,
                            blank=False, max_length=200)

    noofseats = models.IntegerField(verbose_name="No. Of Seats")

    def __str__(self):
        return f"{self.floor} - {self.type}"


class System(Master):  # Renamed to System
    category_CHOICES = [
        ('LAPTOP', 'Laptop'),
        ('DESKTOP', 'Desktop'),
    ]
    rental_or_own_CHOICES = [  # Renamed to rental_or_own_CHOICES
        ('rental', 'Rental'),
        ('own', 'Own'),
    ]

    branch = models.ForeignKey(Branch, on_delete=models.CASCADE, limit_choices_to={"isactive": True})
    category = models.CharField(max_length=10, choices=category_CHOICES)
    rentalorown = models.CharField(max_length=10, choices=rental_or_own_CHOICES)
    brand = models.ForeignKey(ComputerBrand, on_delete=models.CASCADE, verbose_name="Brand",
                              null=False, blank=False, limit_choices_to={"isactive": True})
    serialno = models.CharField(max_length=100, blank=True, null=True)
    person = models.ForeignKey(User, on_delete=models.CASCADE, related_name="SystemPersons", verbose_name="Responsible Person", limit_choices_to=Q(is_active=True) & ~Q(groups__name__in=['Student']))
    dateofpurchase = models.DateField()
    dateofreturn = models.DateField(blank=True, null=True)
    actualdateofreturn = models.DateField(blank=True, null=True)
    amount = models.IntegerField(blank=True, null=True)
    code = models.CharField(max_length=100, blank=True, editable=False, unique=True)  # Adding Code field

    def save(self, *args, **kwargs):
        if not self.code:
            prefix = "OTSL" if self.Category == 'LAPTOP' else "OTSD"
            count = System.objects.filter(Category=self.category).count() + 1
            formatted_count = str(count).zfill(2)
            self.code = f"{prefix}{formatted_count}"
        super(System, self).save(*args, **kwargs)

    def __str__(self):
        return f"{self.code} - {self.category} - {self.rentalorown}"


class RoomAllocation(Transaction):  # Renamed to Allocation
    reservation_CHOICES = [
        ('class', 'Class'),
        ('meeting', 'Meeting'),
    ]
    branch = models.ForeignKey(Branch, on_delete=models.CASCADE, limit_choices_to={"isactive": True})
    reservation_type = models.CharField(max_length=10, choices=reservation_CHOICES)
    batch = models.ForeignKey(Batch, on_delete=models.CASCADE, null=True, blank=True, limit_choices_to={"isactive": True, "isclosed": False})
    person = models.ForeignKey(User, on_delete=models.CASCADE, related_name="RoomAllocationPersons", verbose_name="Person", limit_choices_to={"isactive": True, "groups__name__notin": ['Student']})
    from_date = models.DateTimeField()
    to_date = models.DateTimeField()
    room = models.ForeignKey(Room, on_delete=models.CASCADE)
    purpose = models.CharField(max_length=500, blank=False)

    def __str__(self):
        return f"{self.reservation_type} - {self.batch} - {self.person}"


class ComputerAllocation(Transaction):
    branch = models.ForeignKey(Branch, on_delete=models.CASCADE, limit_choices_to={"isactive": True})
    batch = models.ForeignKey(Batch, on_delete=models.CASCADE, limit_choices_to={"isactive": True, "isclosed": False})

    student = models.ForeignKey(StudentShort, on_delete=models.CASCADE, limit_choices_to={"isactive": True})
    computer = models.ForeignKey(System, on_delete=models.CASCADE, limit_choices_to={"isactive": True})
    from_date = models.DateTimeField()
    to_date = models.DateTimeField()

    def __str__(self):
        return f"{self.batch} - {self.student}"
