from django import forms

from Evaluation.models import Evaluation


class QuestionBankForm(forms.ModelForm):
    question = forms.CharField(widget=forms.Textarea(attrs={'rows':10, 'cols':80}))
    answer = forms.CharField(widget=forms.Textarea(attrs={'rows':10, 'cols':80}),required=False)
    option1 = forms.CharField(widget=forms.TextInput(attrs={'size': 80}), required=False)
    option2 = forms.CharField(widget=forms.TextInput(attrs={'size': 80}), required=False)
    option3 = forms.CharField(widget=forms.TextInput(attrs={'size': 80}), required=False)
    option4 = forms.CharField(widget=forms.TextInput(attrs={'size': 80}), required=False)

class EvaluationForm(forms.ModelForm):
    class Meta:
        model=Evaluation
        fields=['question','answer','assignevaluation','student']
        # widgets = {
        # 'password': forms.PasswordInput()
        # }


# class AssignmentEvaluationStudentForm(forms.ModelForm):
#     # forms.Select()
#     question = forms.CharField(widget=forms.Textarea(attrs={'rows':10, 'cols':80}))
#     answer = forms.CharField(widget=forms.Textarea(attrs={'rows':10, 'cols':80}),required=False)
#     option1 = forms.CharField(widget=forms.TextInput(attrs={'size': 80}), required=False)
#     option2 = forms.CharField(widget=forms.TextInput(attrs={'size': 80}), required=False)
#     option3 = forms.CharField(widget=forms.TextInput(attrs={'size': 80}), required=False)
#     option4 = forms.CharField(widget=forms.TextInput(attrs={'size': 80}), required=False)