from import_export import resources, fields
from import_export.fields import Field
from import_export.widgets import ForeignKeyWidget

from Evaluation.models import QuestionTopic, QuestionBank


class QuestionBankResource(resources.ModelResource):
    questiontype = Field(attribute="questiontype", column_name="Question Type")
    level = Field(attribute="level", column_name="Level")
    topic = fields.Field(
        column_name='Topic',
        attribute='topic',
        widget=ForeignKeyWidget(QuestionTopic, field='topic'))
    question = Field(attribute="question", column_name="question")
    answer = Field(attribute="answer", column_name="answer")
    class Meta:
        model = QuestionBank
        fields = ('questiontype', 'level', 'topic', 'question', 'answer')
        export_order = ('question', 'answer', 'topic', 'questiontype', 'level')
