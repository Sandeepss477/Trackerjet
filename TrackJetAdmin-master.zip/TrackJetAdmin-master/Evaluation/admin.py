from django.contrib import admin
from import_export.admin import ExportMixin

from AdminApp.admin import MasterAdmin
from Evaluation.forms import QuestionBankForm
from Evaluation.models import QuestionTopic, QuestionBank, CreateEvaluation, AssignEvaluation, Evaluation
from django.utils.html import format_html

from Evaluation.resources import QuestionBankResource
from Students.models import StudentShort


# Register your models here.

class QuestionTopicAdmin(MasterAdmin):
    list_display = ['topic', 'course']
    def get_form(self, request, obj=None, **kwargs):
        form = super().get_form(request, obj, **kwargs)
        form.base_fields['course'].widget.can_change_related = False
        form.base_fields['course'].widget.can_add_related = False
        form.base_fields['course'].widget.can_view_related = False
        return form

class QuestionBankAdmin(ExportMixin, MasterAdmin):
    list_display = ['modify_question', 'questiontype','level','topic',  'course']
    search_fields = ['question__contains']
    list_filter = ("course", "questiontype", "topic", "level")
    ordering = ('course','topic','level')

    form = QuestionBankForm
    resource_class = QuestionBankResource

    def modify_question(self, obj):
        #return format_html('<b>OneTeam</b>')
        #q = obj.question
        q = obj.question.replace("\n", '<br>').replace("\t", "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;")
        if q.find("<code>") != -1:
            # q = q.replace("\t", "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;")
            #if q.find("\n") != -1:

            return format_html(q.replace("<code>",'<div style="background-color:#F2EAE8!important;border: 1px solid #d6d6d6!important;color:black">').replace("</code>",'</div>'))
        else:
            return format_html(q)

    modify_question.allow_tags = True
    #modify_question.short_description = "Fees"

    def get_form(self, request, obj=None, **kwargs):
        form = super().get_form(request, obj, **kwargs)
        # fieldlist = ['course', 'topic']
        # for fld in fieldlist:
        #     form.base_fields[fld].widget.can_change_related = False
        #     form.base_fields[fld].widget.can_add_related = False
        #     form.base_fields[fld].widget.can_view_related = False
        return form

class CreateEvaluationAdmin(MasterAdmin):
    list_display = ['evaluationdate', 'batch','evaluationtype','noofquestions','totalmarks','view_print_link']
    #search_fields = ['question__contains']
    list_filter = ("course", "batch",)
    ordering = ('evaluationdate',)
    filter_horizontal = ('questiontopic',)

    def view_print_link(self, obj):
        return format_html('<a href="/admin/Evaluation/generate_questionpaper/?id={}" target="_blank">Go</a>', obj.id)
        # if(obj.BalanceAmount > 0):
        #     return format_html('<a href="/admin/Students/feereceipt/add/?fee={}">Pay</a>', obj.id)
        # else:
        #     return ""

    view_print_link.allow_tags = True
    view_print_link.short_description = "Print"

    def get_form(self, request, obj=None, **kwargs):
        form = super().get_form(request, obj, **kwargs)
        fieldlist = ['course', 'batch']
        for fld in fieldlist:
            form.base_fields[fld].widget.can_change_related = False
            form.base_fields[fld].widget.can_add_related = False
            form.base_fields[fld].widget.can_view_related = False
        return form

class AssignEvaluationAdmin(MasterAdmin):
    list_display = ['view_programURL','evaluation', 'student','examdate','completed','marks']
    #search_fields = ['question__contains']
    list_filter = ("evaluation","examdate", "completed",)
    list_display_links = ('evaluation',)
    ordering = ('-examdate',"-marks")
    #

    def view_programURL(self, obj):
        evaluationtype = obj.evaluation.evaluationtype
        if evaluationtype == "Program":
            return format_html('<a href="{}" target="_blank">{}</a>', obj.programURL, obj.evaluation.evaluationtype)
        elif evaluationtype == "Q&A":
            return format_html('<a href="/admin/Evaluation/exam_QA/{}/{}" target="_blank">{}</a>', obj.id, obj.student.id, obj.evaluation.evaluationtype)
            # return format_html('<a href="/admin/Evaluation/evaluation/?id={}" target="_blank">{}</a>', obj.id,
            #                    obj.evaluation.evaluationtype)


    view_programURL.allow_tags = True
    view_programURL.short_description = "Question URL"

    def get_queryset(self, request):
        queryset = super().get_queryset(request)
        # print("Hello")
        # queryset = queryset.filter(created_user__username__exact= "admin")
        current_user = request.user
        # group_names = current_user.groups.values_list("name", flat=True)
        # print(group_names)
        # print(current_user.groups.filter(name="Student").exists())
        # queryset = queryset.filter(created_user__in=[2, 1])
        if (current_user.groups.filter(name="Student").exists() == True):
            student = StudentShort.objects.get(user=current_user)
            queryset = queryset.filter(student=student)

        #
        # queryset = queryset.annotate(
        #     _studentcallstatus_count=Count("studentcallstatus"),

        # )
        return queryset

    __isStudent = False

    # def get_readonly_fields(self, request, obj=None):
    #     print("readonly")
    #
    #     # print(self.model._meta.get_fields())
    #     self.readonly_fields = ['programURL','examdate','marks']
    #     # if request.user.is_superuser:
    #     if self.__isStudent == True:
    #         # print("jj")
    #
    #         return self.readonly_fields
    #     else:
    #         self.readonly_fields = []
    #
    #     return self.readonly_fields

    # def get_readonly_fields(self, request, obj=None):
    #     return []
    #     # if self.__isStudent == True:
        #     return [f.name for f in self.model._meta.fields]
        # else:
        #     return []
        # if request.user.is_staff:
        #     if request.user.is_superuser:
        #         return []
        #     else:
        #         return [f.name for f in self.model._meta.fields]

        # fields = []
        # for field in [f.name for f in self.model._meta.get_fields()]:
        #     if field != 'completed':
        #         fields.append(field)
        # return fields

    # __is_Load = False
    def get_form(self, request, obj=None, **kwargs):
        # print("form")
        # print(self.__is_Load)
        # self.readonly_fields = []
        form = super().get_form(request, obj, **kwargs)
        # if self.__is_Load == False:
        #     print("Hi")
        #     self.__is_Load = True

        current_user = request.user
        fieldlist = []
        #print(form.get_fields())

        if (current_user.groups.filter(name="Student").exists() == True):
            # fields = self.readonly_fields()
            # self.readonly_fields = fields
            # self.__isStudent = True
            fieldlist = []
            fields = ['evaluation', 'student', 'programURL', 'examdate', 'marks', 'isactive']
            for fld in fields:
                form.base_fields[fld].disabled = True
        else:
            fieldlist = ['evaluation','student']
        for fld in fieldlist:
            form.base_fields[fld].widget.can_change_related = False
            form.base_fields[fld].widget.can_add_related = False
            form.base_fields[fld].widget.can_view_related = False
        return form


admin.site.register(QuestionTopic, QuestionTopicAdmin)
admin.site.register(QuestionBank, QuestionBankAdmin)
admin.site.register(CreateEvaluation, CreateEvaluationAdmin)
admin.site.register(AssignEvaluation, AssignEvaluationAdmin)
admin.site.register(Evaluation)