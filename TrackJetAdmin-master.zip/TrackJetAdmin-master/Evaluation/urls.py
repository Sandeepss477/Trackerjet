from django.urls import path

from Evaluation import views

urlpatterns = [
    path('generate_questionpaper/', views.generate_questionpaper),
    path('exam_QA/<int:evaluationid>/<int:studentid>', views.exam_QA),
    path('navigate_question/', views.navigate_question),
    path('submit_evaluation/', views.submit_evaluation),
]