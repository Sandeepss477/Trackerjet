from django.shortcuts import render
from django.http import HttpResponse, JsonResponse
from datetime import datetime
from reportlab.lib.pagesizes import A4
from io import BytesIO
from reportlab.pdfgen import canvas
# from reportlab.lib.styles import ParagraphStyle
# from reportlab.platypus import Paragraph
import textwrap

from Evaluation import forms
from Evaluation.models import CreateEvaluation, QuestionBank, AssignEvaluation


# Create your views here.

def submit_evaluation(request):
    # evaluationForm = forms.EvaluationForm
    if request.method == 'POST':
        assignevaluation = int(request.POST.get("assignevaluation"))
        student = int(request.POST.get("student"))
        questionid = int(request.POST.get("question"))
        answer = (request.POST.get("answer"))
        print(assignevaluation)
        print(student)
        print(questionid)
        print(answer)


        # evaluationForm = forms.EvaluationForm(request.POST)
        # print(evaluationForm.instance.assignevaluation)
        # print(evaluationForm.instance.student)
        # print(evaluationForm.instance.question)
        # print(evaluationForm.instance.answer)

        response = JsonResponse({"Success": "Saved Successfully"})

        return response






def navigate_question(request):

    questionid = int(request.POST.get("question"))

    navigation = request.POST.get("navigation")
    # print(navigation)
    # if request.method == 'POST':
    #     print("POST")

    questionidlist = request.session['question_ids']

    # print(questionid)

    questionidindex = questionidlist.index(questionid)
    if(navigation == "Previous"):
        questionidindex = questionidindex - 1
    else:
        questionidindex = questionidindex + 1
    # print(questionidindex)
    if(questionidindex > -1 and questionidindex <= (len(questionidlist) - 1)):
        qs_question = QuestionBank.objects.only('question').get(id=questionidlist[questionidindex])
        output = {
        'batchname': request.session['batchname'],
        'totalmarks': request.session['totalmarks'],
        'studentname': request.session['studentname'],
        'question': qs_question,
        'assignevaluation': request.session['evaluationid'],
        'student': request.session['studentid'],

            }
        response = render(request, 'exam_QA.html', context=output)
    else:
        if(navigation == "Previous"):
            response = JsonResponse({"error": "No previous question"})
        else:
            response = JsonResponse({"error": "No next question"})

    return response

def exam_QA(request,evaluationid,studentid):
    # try:

        # id = request.GET.get('id', '')
        assignevaluation = AssignEvaluation.objects.get(id=evaluationid)
        batchname = assignevaluation.evaluation.batch.batch
        totalmarks = assignevaluation.evaluation.totalmarks
        studentname = assignevaluation.student.studentname
        qs_questionids = QuestionBank.objects.filter(questiontype=assignevaluation.evaluation.evaluationtype).values_list('id', flat=True)

        print(qs_questionids.query)
        print(list(qs_questionids))


        request.session['batchname'] = batchname
        request.session['totalmarks'] = totalmarks
        request.session['studentname'] = studentname
        questionidlist = list(qs_questionids)
        request.session['question_ids'] = questionidlist
        request.session['evaluationid'] = evaluationid
        request.session['studentid'] = studentid

        # print(s[0])
        # qs_question = QuestionBank.objects.filter(id=s[0]).values('id','question')
        # qs_question = QuestionBank.objects.filter(id=s[0]).only('question')
        qs_question = QuestionBank.objects.only('question').get(id=questionidlist[0])
        # print(qs_question.id)
        # print(qs_question.question)
        # print(totalmarks)
        # for qs in qs_questionids:
        #     print(qs)
        output = {
            'batchname':batchname,
            'totalmarks':totalmarks,
            'studentname':studentname,
            'question':qs_question,
            'assignevaluation':evaluationid,
            'student':studentid,

        }
        response = render(request, 'exam_QA.html', context=output)
        # response.set_cookie('course_id', course.id)
        return response

    # except:
    #     print("error")
    #     res = {"message": "Something went wrong"}
def generate_questionpaper(request):
    try:
        id = request.GET.get('id', '')
        response = HttpResponse(content_type="application/pdf")
        d = datetime.today().strftime("%Y-%m-%d")
        response['Content-Disposition'] = f"inline; filename='{d}.pdf'"
        buffer = BytesIO()
        p = canvas.Canvas(buffer, pagesize=A4)
        fontsize = 15
        headingY = 800
        printY = headingY - 30
        p.setFont("Helvetica", fontsize, leading=None)
        p.setFillColorRGB(.29296875, 0.453125, 0.609375)
        p.drawString(260, headingY, "Question Paper")
        evaluation = CreateEvaluation.objects.get(id=id)
        batchname = evaluation.batch.batch
        totalmarks = evaluation.totalmarks
        p.setFont("Helvetica", fontsize - 4, leading=None)


        p.drawString(180, printY, f"Batch : {batchname}")
        printY = printY - 30
        p.drawString(480, printY, f"Total Marks : {totalmarks}")

        qs_questions = QuestionBank.objects.filter(questiontype=evaluation.evaluationtype)
        index = 0
        originalstring = ""
        for qs in qs_questions:
            # if index > 1:
            #     break
            printY = printY - 30
            index = index + 1
            p.drawString(20, printY, f"{index}.")
            # p.drawString(35, printY, f"{qs.question}")
            originalstring = f"{qs.question}"
            # originalstring = originalstring.replace("\t", "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;")
            if len(originalstring) > 110:
                # print(index)
                originalstring = originalstring.replace("\n", '~~')
                wrap_text = textwrap.wrap(originalstring, width=110)
                print(len(wrap_text))
                for w in wrap_text:

                    # breakcount = w.count("~~")
                    # print(breakcount)
                    # print(printY)
                    w = w.replace("~~", "\n")
                    print(w)
                    # p.drawString(35, printY, w)
                    t = p.beginText()
                    t.setTextOrigin(35, printY)
                    # print(w)
                    t.textLines(w, trim=0)
                    p.drawText(t)
                    printY = (printY - 15)

            else:
                originalstring = originalstring + "----"
                # p.drawString(35, printY, originalstring + "---")
                breakcount = originalstring.count("\n")
                # print(breakcount)
                t = p.beginText()
                t.setTextOrigin(35, printY)
                t.textLines(originalstring)
                p.drawText(t)
                printY = printY - (15*breakcount)
            # p1 = Paragraph(f"{qs.question}")
            # p1.wrap(600,600)
            # p1.drawOn(p,35,printY)





        p.setTitle(f"Question Paper")
        p.showPage()
        p.save()

        pdf = buffer.getvalue()
        buffer.close()
        response.write(pdf)
        return response

    except:
        res = {"message": "Something went wrong"}