from django.db import models

from AdminApp.models import Master, Course, Batch, Transaction
from Students.models import StudentShort


# Create your models here.

class QuestionTopic(Master):
    course = models.ForeignKey(Course, on_delete=models.CASCADE, verbose_name="Course",
                               null=False, blank=False, limit_choices_to={"isactive": True})
    topic = models.CharField(max_length=200, verbose_name="Topic", null=False, blank=False)

    def __str__(self):
        return f" {self.topic}"



QuestionType_CHOICES = (
        ('Program', 'Program'),
        ('MCQ', 'MCQ'),
        ('Q&A', 'Q&A'),
    )
class QuestionBank(Master):

    LEVEL_CHOICES = (
        ('Easy', 'Easy'),
        ('Medium', 'Medium'),
        ('Difficult', 'Difficult'),
    )
    OPTION_CHOICES = (
        ('Option I', 'Option I'),
        ('Option II', 'Option II'),
        ('Option III', 'Option III'),
        ('Option IV', 'Option IV'),
    )
    course = models.ForeignKey(Course, on_delete=models.CASCADE, verbose_name="Course",
                               null=False, blank=False, limit_choices_to={"isactive": True})
    questiontype = models.CharField(choices=QuestionType_CHOICES, verbose_name="Question Type", null=False,
                                  blank=False, max_length=200)
    level = models.CharField(choices=LEVEL_CHOICES, verbose_name="Question Level", null=False,
                                    blank=False, max_length=200)
    topic = models.ForeignKey(QuestionTopic, on_delete=models.CASCADE, verbose_name="Topic",
                               null=False, blank=False, limit_choices_to={"isactive": True})

    question = models.CharField(max_length=500, verbose_name="Question", null=False, blank=False)

    option1 = models.CharField(max_length=200, verbose_name="Option I", null=True, blank=True)
    option2 = models.CharField(max_length=200, verbose_name="Option II", null=True, blank=True)
    option3 = models.CharField(max_length=200, verbose_name="Option III", null=True, blank=True)
    option4 = models.CharField(max_length=200, verbose_name="Option IV", null=True, blank=True)

    answer = models.CharField(max_length=500, verbose_name="Answer", null=True, blank=True)

    mcqanswer = models.CharField(choices=OPTION_CHOICES, verbose_name="MCQ Anwer", null=True,
                             blank=True, max_length=200)

    def __str__(self):
        return f" {self.question} of {self.course}"




class CreateEvaluation(Master):
    course = models.ForeignKey(Course, on_delete=models.CASCADE, verbose_name="Course",
                               null=False, blank=False, limit_choices_to={"isactive": True})
    batch = models.ForeignKey(Batch, on_delete=models.CASCADE, verbose_name="batch", blank=False,
                              related_name="evaluationbatches", limit_choices_to={"isactive": True})
    evaluationdate = models.DateField(verbose_name="Evaluation Date")
    evaluationtype = models.CharField(choices=QuestionType_CHOICES, verbose_name="Evaluation Type", null=False,
                                    blank=False, max_length=200)
    noofquestions = models.IntegerField(verbose_name="No. Of Questions")
    questiontopic = models.ManyToManyField(QuestionTopic, related_name="EvaluationTopics", blank=False, verbose_name="Question Topic")
    random = models.BooleanField(default=True,verbose_name="Random")
    norepeat = models.BooleanField(default=True, verbose_name="No Repeat")
    totalmarks = models.IntegerField(verbose_name="Total Marks")

    def __str__(self):
        return f"{self.batch} - {self.evaluationdate}"

class AssignEvaluation(Master):
    evaluation = models.ForeignKey(CreateEvaluation, on_delete=models.CASCADE, verbose_name="Evaluation",
                               null=False, blank=False, limit_choices_to={"isactive": True})
    student = models.ForeignKey(StudentShort, on_delete=models.CASCADE, verbose_name="Student",
                               null=False, blank=False, limit_choices_to={"isactive": True})

    programURL = models.CharField(max_length=500, verbose_name="Program URL", null=True, blank=True)

    examdate = models.DateField(verbose_name="Exam Date", null=True, blank=True)

    completed = models.BooleanField(default=False, verbose_name="Completed")

    marks = models.IntegerField(verbose_name="Marks", null=True, blank=True)

    actualexamdate = models.DateField(verbose_name="Exam Date", null=True, blank=True)


    def __str__(self):
        return f"{self.evaluation} - {self.student}"

class Evaluation(Transaction):
    assignevaluation = models.ForeignKey(AssignEvaluation, on_delete=models.CASCADE, verbose_name="Evaluation",
                                   null=False, blank=False, limit_choices_to={"isactive": True}, related_name="AssignEvaluations")

    student = models.ForeignKey(StudentShort, on_delete=models.CASCADE, verbose_name="Student",
                                null=False, blank=False, limit_choices_to={"isactive": True}, related_name="EvaluationStudents")

    question = models.ForeignKey(QuestionBank, on_delete=models.CASCADE, verbose_name="Question",
                                   null=False, blank=False, limit_choices_to={"isactive": True}, related_name="EvaluationQuestions")

    answer = models.CharField(max_length=500, verbose_name="Answer", null=True, blank=True)

    marks = models.IntegerField(verbose_name="Marks", null=True, blank=True)

    def __str__(self):
        return f"{self.student}"

