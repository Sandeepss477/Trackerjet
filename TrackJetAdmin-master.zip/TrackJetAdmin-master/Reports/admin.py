from django.contrib import admin
from django.db.models import Count
from django.utils.html import format_html
from import_export.admin import ExportMixin

from AdminApp.admin import TransactionAdmin
from Reports.models import LeadReport
from Reports.resources import LeadReportResource
from Students.models import Student
from django.contrib.admin import DateFieldListFilter


# Register your models here.
class LeadReportAdmin(ExportMixin, admin.ModelAdmin):
    resource_class = LeadReportResource
    list_display = ['student_link', 'No', 'phone', 'email', 'course', 'teammember', 'enquirydate', 'enquirystatus', 'enquirysource', 'yearofpass', 'district', 'registered']
    search_fields = ['student__startswith', 'course__contains']
    list_filter = ("registered", "enquirystatus", "course", "enquirysource", "teammember", "enquirydate")
    date_hierarchy = "enquirydate"
    list_per_page = 10

    def student_link(self, obj):
        #return u'<a href="/student/%s/">%s</a>' % (obj.student, obj.student)
        return format_html('<a href="/admin/Students/student/{}/change/">{}</a>', obj.ID, obj.student)

    student_link.allow_tags = True
    student_link.short_description = "STUDENT"


    def has_add_permission(self, request):
        return False

    def has_change_permission(self, request):
        return False

    class Media:
        js = ('admin/js/jquery.init.js', 'list_filter_collapse.js')




admin.site.register(LeadReport, LeadReportAdmin)
