from django.db import models

# Create your models here.
class LeadReport(models.Model):
    No = models.BigIntegerField(primary_key=True)
    ID = models.BigIntegerField()
    student = models.CharField(max_length=200, verbose_name="Student")
    phone = models.CharField(max_length=12, verbose_name="Phone")
    email = models.CharField(max_length=200, verbose_name="Email")
    course = models.CharField(max_length=200, verbose_name="Course")
    teammember = models.CharField(max_length=200, verbose_name="Team Member")
    enquirydate = models.DateField(verbose_name="Enquiry Date")
    enquirystatus = models.CharField(max_length=200, verbose_name="Enquiry Status")
    enquirysource = models.CharField(max_length=200, verbose_name="Enquiry Source")
    yearofpass = models.CharField(max_length=4, verbose_name="Year of Pass")
    district = models.CharField(max_length=200, verbose_name="District")
    registered = models.CharField(max_length=200, verbose_name="Registered")

    class Meta:
        managed = False
        db_table = 'leadreport'