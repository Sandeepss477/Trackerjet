from import_export import resources
from import_export.fields import Field

from Reports.models import LeadReport


class LeadReportResource(resources.ModelResource):
    # student = Field(attribute="student", column_name="student")
    # phone = Field(attribute="phone", column_name="phone")
    # percentage = Field(attribute="email", column_name="email")
    class Meta:
        model = LeadReport
        # fields = ('student', 'phone', 'email')
