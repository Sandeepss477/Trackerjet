(function($){
$(document).ready(function($) {
        var isVisible = true;
        $('#changelist-filter').wrap('<div id="outer-filters"></div>')
        $('<div id="show-filters" style="float: right;"><p><a href="#" id="filter-text">Show</a></p>').prependTo('#outer-filters');
        if (window.location.href.indexOf("?") == -1) {
            $('#changelist-filter').hide('fast');
            $("#filter-text").text("Show");
            isVisible = false;
        }
        else
            $("#filter-text").text("Hide");

        $('#show-filters').click(function() {

            if(isVisible)
            {
                $("#filter-text").text("Show");
            }
            else
            {
                $("#filter-text").text("Hide");
            }

            $('#changelist-filter').toggle('fast')

            isVisible = !isVisible;


        });
//$('#changelist').removeClass('filtered');
});

})(django.jQuery);