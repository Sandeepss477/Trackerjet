from urllib.parse import urlencode

from django.contrib import admin
from django.contrib.admin import AdminSite
from django.contrib.auth.models import User
from django.db import models
from abc import ABC, abstractmethod
from django.core.validators import RegexValidator

from django.urls import reverse
from django.utils.html import format_html
from smart_selects.db_fields import ChainedForeignKey
from django.db.models import Count
from AdminApp.forms import BranchForm, DistrictsAdminForm, CourseAdminForm, BatchForm


#from django.contrib.auth.models import AbstractUser

# Create your models here.
# Abstract class Master is a base class which is used to add common fields
class Master(models.Model):
    created_date = models.DateTimeField(auto_now_add=True)
    isactive = models.BooleanField(default=True,verbose_name="Active")
    created_user = models.ForeignKey(User, null=True, blank=True, on_delete=models.CASCADE)
    class Meta:
        abstract = True
        ordering = ['-isactive']


class Transaction(models.Model):
    created_date = models.DateTimeField(auto_now_add=True)
    #isactive = models.BooleanField(default=True,verbose_name="Active")
    created_user = models.ForeignKey(User, null=True, blank=True, on_delete=models.CASCADE)

    class Meta:
        abstract = True



#class State
class State(Master):
    statename = models.CharField(max_length=200, unique=True)

    class Meta:
        verbose_name_plural = "States"
        ordering = ['-isactive']

    def __str__(self):
        return self.statename

#class District
class District(Master):
    state = models.ForeignKey(State, on_delete=models.CASCADE, limit_choices_to={"isactive": True})
    districtname = models.CharField(max_length=200, unique=True)

    class Meta:
        verbose_name_plural = "Districts"

    def __str__(self):
        return self.districtname

#class Qualification
class Qualification(Master):
    qualificationname = models.CharField(max_length=200, unique=True)

    class Meta:
        verbose_name_plural = "Qualifications"

    def __str__(self):
        return self.qualificationname


#class EnquirySource
class EnquirySource(Master):
    enquirysourcename = models.CharField(max_length=200, unique=True)

    class Meta:
        verbose_name_plural = "Enquiry sources"

    def __str__(self):
        return self.enquirysourcename

#class Branch
class Branch(Master):
    phone_regex = RegexValidator(regex=r'^\+?1?\d{9,10}$',
                                 message="Phone number must be entered in the format: '9999999999'. Up to 10 digits allowed.")
    branch = models.CharField(max_length=200)
    branch_code = models.CharField(max_length=50, unique=True, null=True)
    address = models.CharField(max_length=500, blank=True)
    street = models.CharField(max_length=200, blank=True)
    state = models.ForeignKey(State, on_delete=models.CASCADE, limit_choices_to={"isactive": True})
    district = ChainedForeignKey(District, chained_field="state", chained_model_field="state", show_all=False, auto_choose=True, sort=True, limit_choices_to={"isactive": True})
    pincode = models.PositiveIntegerField(blank=True, null=True)
    mobile = models.CharField(validators=[phone_regex], max_length=12)
    email = models.EmailField(max_length=200, blank=True)

    class Meta:
        verbose_name_plural = "Branches"
        ordering = ("state", "district")

    def __str__(self):
        return self.branch


#class FollowUpStatus
class FollowUpStatus(Master):
    followupstatusname = models.CharField(max_length=200, unique=True)
    BOOL_CHOICES = ((True, 'Yes'), (False, 'No'))
    followupstatus = models.BooleanField(choices=BOOL_CHOICES)

    class Meta:
        verbose_name_plural = "Follow up statuses"

    def __str__(self):
        return self.followupstatusname


#class Company
class Company(Master):
    phone_regex = RegexValidator(regex=r'^\+?1?\d{9,10}$',
                                 message="Phone number must be entered in the format: '9999999999'. Up to 10 digits allowed.")
    company = models.CharField(max_length=200, unique=True)
    address1 = models.CharField(max_length=500, blank=True)
    address2 = models.CharField(max_length=500, blank=True)
    address3 = models.CharField(max_length=500, blank=True)
    phone = models.CharField(validators=[phone_regex], max_length=12)
    email = models.EmailField(max_length=200, blank=True)
    website = models.CharField(max_length=200, blank=True)
    # in order to work the following field, the Pillow package must be installed..
    #pip install pillow
    Logo = models.ImageField(upload_to='images')

    def logo_image(self):
        return format_html('<img src="{0}" style="width: 145px; height:45px;" />'.format(self.Logo.url))


    logo_image.allow_tags = True

    class Meta:
        verbose_name_plural = "Companies"

    def __str__(self):
        return self.company

# MasterData table for storing the data which the end user doesn't want to enter..
# i.e. the data will be added by the developer or administrator
class MasterData(Master):
    name = models.CharField(max_length=200, unique=True)
    value = models.CharField(max_length=200)
    type = models.CharField(max_length=200)

    class Meta:
        unique_together = ('value', 'type',)
        verbose_name_plural = "Master Data"

    def __str__(self):
        return self.name


class Syllabus(Master):
    syllabus = models.CharField(max_length=200, unique=True,)

    class Meta:
        verbose_name_plural = "Syllabus"

    def __str__(self):
            return self.syllabus


class Course(Master):
    course = models.CharField(max_length=200, unique=True)
    coursecode = models.CharField(max_length=200, unique=True, null=True)
    trainers = models.ManyToManyField(User, related_name="UserTrainers", blank=True, limit_choices_to={"is_active": True, "groups__name": 'Faculty'})
    class Meta:
        verbose_name_plural = "Course"
    def __str__(self):
        return self.course


class CourseFees(Transaction):
    course = models.ForeignKey(Course, on_delete=models.CASCADE, limit_choices_to={"isactive": True})
    feestype = models.ForeignKey(MasterData, on_delete=models.CASCADE, verbose_name = "Fees Type", limit_choices_to={"isactive": True, "type": 'Fee Type'})
    amount = models.IntegerField()
    tax = models.FloatField()
    installment_period = models.IntegerField()
    class Meta:
        verbose_name_plural = "Course Fees"

    def __str__(self):
        return f"{self.course} with fee type {self.feestype}"
        # return str(self.course) + " with fee type " + str(self.feestype)


class CourseSyllabus(Transaction):
    course = models.ForeignKey(Course, on_delete=models.CASCADE, limit_choices_to={"isactive": True})
    day = models.ForeignKey(MasterData, on_delete=models.CASCADE, null=True, limit_choices_to={"isactive": True, "type": 'Day'})
    syllabus = models.ForeignKey(Syllabus, on_delete=models.CASCADE, limit_choices_to={"isactive": True})
    percentage = models.IntegerField()
    changeinstudent = models.BooleanField(default=True,verbose_name="Change in Student Details")

    class Meta:
        verbose_name_plural = "Course Syllabus"
        ordering = ['percentage']

    def __str__(self):
        return f"{self.course} with syllabus {self.syllabus}"
        #return str(self.course) + " with syllabus " + str(self.syllabus)

class UserProfile(models.Model):
    STATUS_CHOICES = (
        ("Resigned", 'Resigned'),
        ("Working", 'Working')
    )

    phone_regex = RegexValidator(regex=r'^\+?1?\d{9,10}$',
                                 message="Phone number must be entered in the format: '9999999999'. Up to 10 digits allowed.")

    user = models.OneToOneField(User, on_delete=models.CASCADE)
    mobile = models.CharField(validators=[phone_regex], max_length=12, verbose_name="Mobile", null=False, blank=False)
    branch = models.ForeignKey(Branch, on_delete=models.CASCADE, limit_choices_to={"isactive": True})
    status = models.CharField(choices=STATUS_CHOICES, max_length=50, verbose_name="Status", null=False, blank=False)

    def __str__(self):
        return f"{self.user} with branch {self.branch}"
        # return str(self.user) + " with branch " + str(self.branch)


# BATCHES  INFORMATION HERE

class Batch(Master):
    batch = models.CharField(max_length=200, unique=True)
    course = models.ForeignKey(Course, on_delete=models.CASCADE, verbose_name="Course",
                               null=True, blank=False, limit_choices_to={"isactive": True})
    start_date = models.DateField()
    start_time = models.TimeField(null=True)
    end_date = models.DateField()
    end_time = models.TimeField(null=True)

    # trainer = ChainedForeignKey(User, chained_field="course", chained_model_field="user", show_all=False,
    #                              auto_choose=True, sort=True, related_name="trainerbatch")

    #trainers = models.ManyToManyField(User, related_name="UserTrainers", blank=True)

    #district = ChainedForeignKey(District, chained_field="state", chained_model_field="state", show_all=False, auto_choose=True, sort=True)

    branch = models.ForeignKey(Branch, on_delete=models.CASCADE, limit_choices_to={"isactive": True}, null=True, blank=False, related_name="batchbranches")

    trainer = models.ForeignKey(User, on_delete=models.CASCADE, verbose_name="Trainer", null=True, blank=False,
                                related_name="trainer", limit_choices_to={"is_active": True, "groups__name": 'Faculty'})
    isclosed = models.BooleanField(default=False, verbose_name="Closed")

    class Meta:
        verbose_name_plural = "Batch"

    def __str__(self):
        return self.batch


class BatchTransfer(Transaction):
    batch = models.ForeignKey(Batch, on_delete=models.CASCADE, verbose_name="batch", blank=False, related_name="batchtransfers", limit_choices_to={"isactive": True})
    trainer = models.ForeignKey(User, on_delete=models.CASCADE, verbose_name="trainer", blank=False, related_name="batchtransfers", limit_choices_to={"is_active": True, "groups__name": 'Faculty'})
    start_date = models.DateTimeField()
    end_date = models.DateField()
    #isclosed = models.BooleanField(default=False, verbose_name="Closed")

    class Meta:
        verbose_name_plural = "Batch Transfer"

    def __str__(self):
        return f"{self.batch.batch} of trainer {self.trainer}"




class UserDataPermission(Transaction):
    user = models.ForeignKey(User, on_delete=models.CASCADE,related_name="user", limit_choices_to={"is_active": True})
    user_permission = models.ForeignKey(User, on_delete=models.CASCADE, verbose_name = "Permitted Users",related_name="user_permission")
    is_permitted = models.BooleanField(default=False)

    class Meta:
        verbose_name_plural = "User Data Permissions"

    def _str_(self):
        return self.user.username






# class CourseSyllabusAdmin(TransactionAdmin):
#     list_display = ['course', 'syllabus', 'percentage']
#
#     form = CourseAdminForm
#     def formfield_for_foreignkey(self, db_field, request, **kwargs):
#         if db_field.name == "course":
#             kwargs["queryset"] = Course.objects.filter(isactive=True)
#         elif db_field.name == "syllabus":
#             kwargs["queryset"] = Syllabus.objects.filter(isactive=True)
#         return super().formfield_for_foreignkey(db_field, request, **kwargs)
#

