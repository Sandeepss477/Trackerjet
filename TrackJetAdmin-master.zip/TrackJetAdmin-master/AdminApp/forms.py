import django.forms.fields
from django import forms
from crispy_forms.helper import FormHelper
from crispy_forms.layout import Submit
from django.forms import DateField

from TrackerJet_Admin import settings


#from AdminApp.models import Batch


#from AdminApp.models import Branch

# https://stackoverflow.com/questions/40804815/on-django-admin-why-is-django-adding-changelist-filters-to-url
# DistrictsAdminForm is created to solve the issue of selecting the state when districts are added..
class DistrictsAdminForm(forms.ModelForm):
    @staticmethod
    def parse_filter_kwargs(**kwargs):
        # print(kwargs['initial'])
        # print(kwargs[1])
        # print(kwargs[2])
        if 'initial' in kwargs:
            if u'_changelist_filters' in kwargs['initial']:
                filters = kwargs['initial'][u'_changelist_filters']
                var, value = filters.split('=')
                if var == u'state':
                    return {'initial': {var: value}}
        return kwargs

    def __init__(self, *args, **kwargs):
        #print(kwargs['initial'])
        kwargs = self.parse_filter_kwargs(**kwargs)
        super(DistrictsAdminForm, self).__init__(*args, **kwargs)


# CourseAdminForm is created to solve the issue of selecting the course when fees are added..
class CourseAdminForm(forms.ModelForm):
    @staticmethod
    def parse_filter_kwargs(**kwargs):
        if 'initial' in kwargs:
            if u'_changelist_filters' in kwargs['initial']:
                filters = kwargs['initial'][u'_changelist_filters']
                var, value = filters.split('=')
                if var == u'course':
                    return {'initial': {var: value}}
        return kwargs

    def __init__(self, *args, **kwargs):
        kwargs = self.parse_filter_kwargs(**kwargs)
        super(CourseAdminForm, self).__init__(*args, **kwargs)

class BranchForm(forms.ModelForm):

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        #from AdminApp.models import District
        #self.fields['district'].queryset = District.objects.filter(isactive=True)

        self.helper = FormHelper()
        # self.helper.form_id = 'id-my-form'
        # self.helper.form_class = 'form-horizontal'
        # self.helper.form_method = 'post'
        # self.helper.form_class = 'form-horizontal'
        # self.helper.label_class = 'col-lg-2'
        # self.helper.field_class = 'col-lg-8'
        self.helper.add_input(Submit('submit', 'Submit'))

    class Meta:
        pass
        #model = Branch
        # See note here: https://docs.djangoproject.com/en/1.10/ref/contrib/admin/#django.contrib.admin.ModelAdmin.form
        #fields = []

class BatchForm(forms.ModelForm):

    # start_date = forms.DateTimeField(
    #     #input_formats=['%d-%m-%YT%H:%M'],
    #     widget=forms.DateTimeInput(
    #         attrs={
    #             'type': 'datetime-local',
    #             'class': 'form-control'
    #         },
    #      #   format='%d-%m-%YT%H:%M'
    #     )
    # )

    start_date = forms.DateField(
        # input_formats=['%d-%m-%YT%H:%M'],
        widget=forms.DateInput(
            attrs={
                'type': 'date',
                'class': 'form-control'
            },
            #   format='%d-%m-%YT%H:%M'
        )
    )

    start_time = forms.TimeField(widget=forms.TimeInput(format='%H:%M', attrs={'placeholder': 'HH:MM', 'required': 'required'}))

    end_date = forms.DateField(
        # input_formats=['%d-%m-%YT%H:%M'],
        widget=forms.DateInput(
            attrs={
                'type': 'date',
                'class': 'form-control'
            },
            #   format='%d-%m-%YT%H:%M'
        )
    )

    end_time = forms.TimeField(
        widget=forms.TimeInput(format='%H:%M', attrs={'placeholder': 'HH:MM', 'required': 'required'}))

    coursehiddenid = forms.CharField(widget=forms.HiddenInput(), required=False)

    def is_valid(self):
        print(self.errors)
        return super(BatchForm, self).is_valid()

    @staticmethod
    def parse_filter_kwargs(**kwargs):
        if 'initial' in kwargs:
            if u'_changelist_filters' in kwargs['initial']:
                filters = kwargs['initial'][u'_changelist_filters']
                var, value = filters.split('=')
                if var == u'batch':
                    return {'initial': {var: value}}
        return kwargs

    def __init__(self, *args, **kwargs):
        kwargs = self.parse_filter_kwargs(**kwargs)
        super(BatchForm, self).__init__(*args, **kwargs)

    #end_date = DateField(input_formats=settings.DATE_INPUT_FORMATS)
    #start_date = django.forms.fields.DateTimeField()

    class Meta:
        #model = Batch
        # fields = "__all__"
        #
        # widgets = {
        #     'start_date': forms.TextInput(attrs={'type': 'datetime-local'}),
        #     'end_date': forms.TextInput(attrs={'type': 'date'}),
        # }

        pass



    # def __init__(self, *args, **kwargs):
    #     super().__init__(*args, **kwargs)
    #     from django.forms import DateTimeInput
    #     #from django.contrib.admin.widgets import AdminDateWidget, AdminSplitDateTime
    #     #self.fields["end_date"].widget = AdminDateWidget()
    #     #self.fields["end_date"].input_formats = settings.DATE_INPUT_FORMATS
    #     #self.fields["start_date"].widget = DateField(input_formats=settings.DATETIME_INPUT_FORMATS)
    #     #self.fields["start_date"].input_formats = settings.DATE_INPUT_FORMATS
    #     #self.fields["start_date"].widget = AdminSplitDateTime()
    #     #self.fields["start_date"].input_formats = ['%d-%m-%YT%H:%M %p']
    #     #print("jj")




