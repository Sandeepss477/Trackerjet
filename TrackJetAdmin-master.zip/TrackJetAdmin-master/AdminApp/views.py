from django.db import connection
from django.http import HttpResponse, HttpResponseRedirect
from django.shortcuts import render

# Create your views here.
import json

from AdminApp.models import Course

def home_view(request):
    if request.user.is_authenticated:
        return HttpResponseRedirect('afterlogin')
    return render(request,'index.html')


def dictfetchall(cursor):
    "Return all rows from a cursor as a dict"
    columns = [col[0] for col in cursor.description]
    return [
        dict(zip(columns, row))
        for row in cursor.fetchall()
    ]

def get_trainersOfCourse(request):
    branchid = request.GET.get('branchid','')
    courseid = request.GET.get('courseid', '')
    start_date = request.GET.get('start_date', '')
    start_time = request.GET.get('start_time', '')
    end_date = request.GET.get('end_date', '')
    end_time = request.GET.get('end_time', '')
    print(branchid)
    print(courseid)
    print(start_date)
    print(start_time)
    print(end_date)
    print(end_time)
    #result = list(Course.objects.filter(id=int(id)).UserTrainers_set.values())
    #print(Course.objects.filter(id=int(id)).query)
    # r = Course.objects.get(id=int(courseid)).trainers.filter(userprofile__branch=int(branchid)).values("id","username")
    # print(r.query)
    # result = Course.objects.get(id=int(courseid)).trainers.filter(userprofile__branch=int(branchid)).values("id","username")
    # print(result)
    # print(list(result))
    # res = result.exclude(batch__start_date__lte = start_date, batch__end_date__gte = end_date, batch__start_time__lte = start_time, batch__end_time__gte = end_time).values("id","username")
    # print(res.query)

    with connection.cursor() as cursor:

        cursor.execute("""SELECT distinct auth_user.id, auth_user.username FROM auth_user
INNER JOIN AdminApp_course_trainers ON (auth_user.id = AdminApp_course_trainers.user_id)
INNER JOIN AdminApp_userprofile ON (auth_user.id = AdminApp_userprofile.user_id)
INNER JOIN AdminApp_batch ON (auth_user.id = AdminApp_batch.trainer_id)
WHERE (AdminApp_course_trainers.course_id = %s AND AdminApp_userprofile.branch_id = %s
and not (start_date <= %s and end_date > %s and start_time <= %s and end_time > %s));""", [courseid, branchid, end_date, start_date, end_time, start_time])
        res = dictfetchall(cursor)
    print(res)





    return HttpResponse(json.dumps(res), content_type="application/json")

def index(request):
    return HttpResponse("Hello World")
