
from django.urls import path, re_path, include

from AdminApp import views

urlpatterns = [
    #re_path(r'^/get_trainersOfCourse/$', views.get_trainersOfCourse)
    #path(r'^index/$', views.index, name='index'),
    #path('index/', views.index, name='index'),
    path('get_trainersOfCourse/', views.get_trainersOfCourse)
]
