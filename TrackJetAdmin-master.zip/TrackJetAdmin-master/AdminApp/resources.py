
from import_export import resources
from import_export.fields import Field

from AdminApp.models import CourseSyllabus


class CourseSyllabusResource(resources.ModelResource):
    course = Field(attribute="course__course", column_name="Course")
    syllabus = Field(attribute="syllabus__syllabus", column_name="Syllabus")
    percentage = Field(attribute="percentage", column_name="Percentage")
    class Meta:
        model = CourseSyllabus
        fields = ('course', 'syllabus', 'percentage')
