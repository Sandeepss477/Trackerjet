from django.apps import AppConfig


class AdminappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'AdminApp'
    verbose_name = 'Settings' # To change the App name in admin page
