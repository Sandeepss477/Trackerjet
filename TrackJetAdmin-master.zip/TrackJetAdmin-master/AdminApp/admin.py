from django import forms
from django.contrib import admin
from django.contrib.admin import AdminSite
from django.contrib.auth.admin import UserAdmin, GroupAdmin
from django.contrib.auth.models import User, Group
from django.db.models import Count
# from django.forms import widgets, models
from django.urls import reverse
from django.db import models
from django.forms import widgets
#from urllib.parse import urlencode

from django.utils.html import format_html
from django.utils.http import urlencode

# from AdminApp import models
from AdminApp.forms import CourseAdminForm, DistrictsAdminForm, BatchForm
from AdminApp.resources import CourseSyllabusResource
from import_export.admin import ImportExportModelAdmin

from AdminApp.models import State, District, Qualification, \
    EnquirySource, Branch, FollowUpStatus, Company, \
    MasterData, Batch, Syllabus, Course, CourseFees, \
    CourseSyllabus, UserProfile, UserDataPermission, BatchTransfer


# in order to order the apps and menu items.....
class TrackerJetAdminSite(AdminSite):

    # def get_app_list(self, app, request):
    #     #print("hiapp")
    #     #pass

    def get_app_list(self, request, app_label=None):
        #print("hi")
        """
        Return a sorted list of all the installed apps that have been
        registered in this site.
        """
        ordering = {
            "Companies": 1,
            "States": 2,
            "Districts": 3,
            "Branches": 4,
            "Enquiry sources": 5,
            "Follow up statuses": 6,
            "Qualifications": 7,
            "Batch": 8,
            "Syllabus": 9,
            "Course": 10,
            "Course Fees":11,
            "Course Syllabus":12,
            "Master Data":13,
            "Employer Details":14,
            "Students": 15,
            "Students Info": 16,
            "Question topics": 16,
            "Question banks": 16,
            "Create evaluations": 16,
            "Assign evaluations": 16,
            "Evaluations": 16,
            "Computer brands": 16,
            "Rooms": 16,
            "Systems": 16,
            "Room allocations": 16,
            "Computer allocations": 16,
            "Student call statuss":16,
            "Users":17,
            "Groups":18,
            "User Data Permissions":19,
            "Batch Transfer":20,
            "Student feess":21,
            "Lead reports": 22,
            "Fee receipts": 23,

        }

        appordering = {
            "Settings": 1,
            "Students": 2,
            "Evaluation": 3,
            "Resourceallocation": 4,
            "Placements": 5,
            "Reports": 6,
            "Authentication and Authorization": 7
        }

        # changing keys of dictionary
        # ordering['Exams'] = ordering["Assign evaluations"]
        # del ordering["Assign evaluations"]

        app_dict = self._build_app_dict(request, app_label)
        # print(app_dict)
        # a.sort(key=lambda x: b.index(x[0]))
        # Sort the apps alphabetically.
        #app_list = sorted(app_dict.values(), key=lambda x: x['name'].lower())

        app_list = list(app_dict.values())
        # print(app_list)
        #print(app_dict.values())

        #app_list = sorted(app_dict.values(), key=lambda x: appordering[x['name']])

        app_list.sort(key=lambda x: appordering[x['name']])



        # Sort the models alphabetically within each app.
        for app in app_list:
            app['models'].sort(key=lambda x: ordering[x['name']])



        return app_list

    # def each_context(self, request):
    #     already_dict = super().each_context(request)
    #     for name in already_dict['available_apps']:
    #         # here you can access current user as request.user
    #         # you can change model name with
    #         name['models'][0]['name'] = 'some name you want'
    #         print(name['models'])
    #     return already_dict

mysite = TrackerJetAdminSite()
admin.site = mysite

class MasterAdmin(admin.ModelAdmin):

    # in order to exclude the field 'created_user' from the form
    exclude = ['created_user']

    list_per_page = 10
    def has_delete_permission(self, request, obj=None):
        # Disable delete
        return False

    # To order Active field last in all forms
    def get_fields(self, request, obj=None, **kwargs):
        fields = super().get_fields(request, obj, **kwargs)
        fields.remove('isactive')
        fields.append('isactive')  # can also use insert
        return fields

    # To save the logged in user id to the table when a record is added.
    # https://stackoverflow.com/questions/6760602/how-can-i-get-current-logged-user-id-in-django-admin-panel
    def save_model(self, request, obj, form, change):
        obj.created_user = request.user
        #print(eval(self.__class__.__name__))
        super().save_model(request, obj, form, change)

    def render_change_form(self, request, context, add=False, change=False, form_url='', obj=None):
        context.update({
            #'show_save': False,
            'show_save_and_continue': False,
            'show_save_and_add_another': False,
            'show_delete': False
        })
        return super().render_change_form(request, context, add, change, form_url, obj)


    class Media:
        js = ('admin/js/jquery.init.js', 'list_filter_collapse.js')


class TransactionAdmin(admin.ModelAdmin):

    # in order to exclude the field 'created_user' from the form
    exclude = ['created_user']
    def has_delete_permission(self, request, obj=None):
        # Disable delete
        return False

    def render_change_form(self, request, context, add=False, change=False, form_url='', obj=None):
        context.update({
            #'show_save': False,
            'show_save_and_continue': False,
            'show_save_and_add_another': False,
            'show_delete': False
        })
        return super().render_change_form(request, context, add, change, form_url, obj)


    # To save the logged in user id to the table when a record is added.
    # https://stackoverflow.com/questions/6760602/how-can-i-get-current-logged-user-id-in-django-admin-panel
    def save_model(self, request, obj, form, change):
        obj.created_user = request.user
        #print(eval(self.__class__.__name__))
        super().save_model(request, obj, form, change)

    class Media:
        js = ('admin/js/jquery.init.js', 'list_filter_collapse.js')





#class used for configuring which all fields need to be listed..
# https://realpython.com/customize-django-admin-python/#providing-links-to-other-object-pages
class StateAdmin(MasterAdmin):
    list_display = ['statename', 'isactive', "view_districts_link"]
    search_fields = ("statename__startswith",)

    def get_queryset(self, request):
        queryset = super().get_queryset(request)
        queryset = queryset.annotate(
            _district_count=Count("district")
        )
        return queryset


    def view_districts_link(self, obj):
        #count = obj.district_set.count() # To optimize query use get_queryset
        count = obj._district_count

        url = (
                reverse("admin:AdminApp_district_changelist")
                + "?"
                + urlencode({"state": f"{obj.id}"})
        )
        #print(url)
        return format_html('<a href="{}">{} Districts</a>', url, count)

    view_districts_link.allow_tags = True
    view_districts_link.short_description = "Districts"


#class used for configuring which all fields need to be listed..
class DistrictAdmin(MasterAdmin):
    list_display = ['districtname', 'state', 'isactive']
    list_filter = ("state",)
    search_fields = ("districtname__startswith",)

    form = DistrictsAdminForm

# Code to remove the add, change and view icon from State dropdown.
# https://stackoverflow.com/questions/48757234/in-django-admin-how-can-i-hide-or-remove-the-pencil-and-x

    def get_form(self, request, obj=None, **kwargs):
        form = super().get_form(request, obj, **kwargs)
        form.base_fields['state'].widget.can_change_related = False
        form.base_fields['state'].widget.can_add_related = False
        form.base_fields['state'].widget.can_view_related = False
        return form

#class used for configuring which all fields need to be listed..
class QualificationAdmin(MasterAdmin):
    list_display = ['qualificationname', 'isactive']


#class used for configuring which all fields need to be listed..
class EnquirySourceAdmin(MasterAdmin):
    list_display = ['enquirysourcename', 'isactive']

# class used for configuring which all fields need to be listed..
class BranchAdmin(MasterAdmin):
    list_display = ['branch', 'branch_code', 'district', 'mobile', 'isactive']
    list_filter = ("state", 'district')
    search_fields = ("branch__startswith",)

    # Django admin display multiple fields on the same line
    # https://stackoverflow.com/questions/5852540/django-admin-display-multiple-fields-on-the-same-line
    # fields = ('branch',
    #           ('address','street'),
    #           ('state','district'),
    #           ('pincode','mobile'),
    #           'email',
    #           'isactive'
    #           )
    # fields = (__all__,
    #           'isactive'
    #           )


    # form = BranchForm
    # add_form_template = "admin/my_form.html"
    # change_form_template = "admin/my_form.html"

    def get_form(self, request, obj=None, **kwargs):
        form = super().get_form(request, obj, **kwargs)
        fieldlist = ['state', 'district']
        for fld in fieldlist:
            form.base_fields[fld].widget.can_change_related = False
            form.base_fields[fld].widget.can_add_related = False
            form.base_fields[fld].widget.can_view_related = False
        return form

    # To filter out the inactive states & districts
    # def formfield_for_foreignkey(self, db_field, request, **kwargs):
    #
    #     if db_field.name == "district":
    #         kwargs["queryset"] = District.objects.filter(isactive = True)
    #     elif db_field.name == "state":
    #         kwargs["queryset"] = State.objects.filter(isactive = True)
    #     return super().formfield_for_foreignkey(db_field, request, **kwargs)

    # def get_form(self, request, obj=None, **kwargs):
    #     print("getform")
    #     form = super(BranchAdmin, self).get_form(request, obj, **kwargs)
    #     form.base_fields['district'].queryset = District.objects.filter(isactive = True)
    #     return form


#class used for configuring which all fields need to be listed..
class FollowUpStatusAdmin(MasterAdmin):
    list_display = ['followupstatusname', 'followupstatus', 'isactive']
    list_filter = ("followupstatus",)
    search_fields = ("followupstatusname__startswith",)

    class Media:
        js = ('admin/js/jquery.init.js', 'list_filter_collapse.js')


class CompanyAdmin(MasterAdmin):
    list_display = ['company', 'logo_image', 'isactive']

    # form = BranchForm
    # add_form_template = "admin/my_form.html"
    # change_form_template = "admin/my_form.html"

#class used for configuring which all fields need to be listed..
class MasterDataAdmin(MasterAdmin):
    list_display = ['name', 'value', 'type', 'isactive']


class SyllabusAdmin(MasterAdmin):
    list_display = ['syllabus']
    list_filter = ("syllabus"),
    search_fields = ("syllabus__startswith"),

    # def has_delete_permission(self, request, obj=None):
    #     # Disable delete
    #     return False

#class used for configuring which all fields need to be listed..
class CourseAdmin(MasterAdmin):
    list_display = ['course', 'coursecode', 'isactive', 'view_fees_link', 'view_syllabus_link']
    filter_horizontal = ('trainers',)

    # fields = [('course'),
    #           ('coursecode'),
    #           ('trainers',),
    #           'isactive'
    #           ]
    # fields = (__all__,
    #           'isactive'
    #           )

    def get_form(self, request, obj=None, **kwargs):
        form = super().get_form(request, obj, **kwargs)
        fieldlist = ['trainers', ]
        for fld in fieldlist:
            form.base_fields[fld].widget.can_change_related = False
            form.base_fields[fld].widget.can_add_related = False
            form.base_fields[fld].widget.can_view_related = False
        return form

    def view_fees_link(self, obj):
        #print(obj.coursefees_set.count().query)
        count = obj.coursefees_set.count()

        url = (
                reverse("admin:AdminApp_coursefees_changelist")
                + "?"
                + urlencode({"course": f"{obj.pk}"})
        )
        # print(url)
        return format_html('<a href="{}">{} Fees</a>', url, count)

    view_fees_link.allow_tags = True
    view_fees_link.short_description = "Fees"

    def view_syllabus_link(self, obj):
        count = obj.coursesyllabus_set.count()
        url = (
                reverse("admin:AdminApp_coursesyllabus_changelist")
                + "?"
                + urlencode({"course": f"{obj.id}"})
        )
        # print(url)
        return format_html('<a href="{}">{} Syllabus</a>', url, count)

    view_syllabus_link.allow_tags = True
    view_syllabus_link.short_description = "Syllabus"

    # def formfield_for_manytomany(self, db_field, request, **kwargs):
    #     if db_field.name == "trainers":
    #         kwargs["queryset"] = User.objects.filter(is_active=True, groups__name='Faculty')
    #     return super(CourseAdmin, self).formfield_for_manytomany(db_field, request, **kwargs)




#class used for configuring which all fields need to be listed..
#https://realpython.com/customize-django-admin-python/#providing-links-to-other-object-pages
class CourseFeesAdmin(TransactionAdmin):
    list_display = ['feestype', 'amount', 'tax', 'installment_period']
    #list_filter = ("course",)
    search_fields = ("course__course__startswith",)
    #readonly_fields = ("feestype",)
    #hidden_menu = True
    form = CourseAdminForm

    add_form_template = "admin/common_form.html"
    change_form_template = "admin/common_form.html"

    def has_module_permission(self, request):
        return False


    # def get_readonly_fields(self, request, obj=None):
    #     if obj:
    #         # obj is not None, so this is an edit
    #         return ['course', ]  # Return a list or tuple of readonly fields' names
    #     else:
    #         # This is an addition
    #         return ['course',]

    # Code to change the title in change list
    def changelist_view(self, request, extra_context=None):
        courseid = request.GET.get("course")
        if(courseid):
            #coursename = Course.objects.filter(id=courseid).values()[0].get("course")
            coursename = Course.objects.get(id=courseid)
            #print(coursename)
            extra_context = {'title': f'Course fees of {coursename}.'}

        return super(CourseFeesAdmin, self).changelist_view(request, extra_context=extra_context)

    def get_form(self, request, obj=None, **kwargs):
        form = super().get_form(request, obj, **kwargs)
        fieldlist = ['course', 'feestype']
        for fld in fieldlist:
            form.base_fields[fld].widget.can_change_related = False
            form.base_fields[fld].widget.can_add_related = False
            form.base_fields[fld].widget.can_view_related = False

        # if(obj == None):
        #     form.base_fields['course'].disabled = True

        return form

    # def formfield_for_foreignkey(self, db_field, request, **kwargs):
    #     if db_field.name == "course":
    #         kwargs["queryset"] = Course.objects.filter(isactive=True)
    #     elif db_field.name == "feestype":
    #         kwargs["queryset"] = MasterData.objects.filter(type="Fee Type", isactive=True)
    #     return super().formfield_for_foreignkey(db_field, request, **kwargs)

class BatchAdmin(MasterAdmin):
    list_display = ['batch', 'branch', 'trainer', 'formatstart_date', 'start_time', 'formatend_date', 'end_time', 'view_transfer_link', 'isclosed', 'isactive']
    list_filter = ("course","trainer","isclosed", "isactive", 'branch')
    search_fields = ("batch__icontains"),

    formfield_overrides = {
        models.TimeField: {'widget': widgets.TimeInput(format='%I:%M %p')},
                           }

    exclude = ['batch', 'created_user']
    #exclude = ['created_user']

    form = BatchForm

    add_form_template = "admin/batch_form.html"
    change_form_template = "admin/batch_form.html"


    def view_transfer_link(self, obj):
        #count = obj.coursefees_set.count()
        # url = (
        #         reverse("admin:AdminApp_batchtransfer_changelist")
        #         + "?"
        #         + urlencode({"batch": f"{obj.id}", "id": f"{obj.course.pk}"})
        # )
        url = (
                reverse("admin:AdminApp_batchtransfer_changelist")
                + "?"
                + urlencode({"batch": f"{obj.id}"})
        )
        return format_html('<a href="{}">Go</a>', url)

    view_transfer_link.allow_tags = True
    view_transfer_link.short_description = "Transfer"


    def formatstart_date(self, obj):
        # return obj.start_date.strftime("%d-%m-%Y %I:%M%p")
        return obj.start_date.strftime("%d-%m-%Y")

    formatstart_date.short_description = 'Start Date'

    def formatend_date(self, obj):
        return obj.end_date.strftime("%d-%m-%Y")

    formatend_date.short_description = 'End Date'

    def get_form(self, request, obj=None, **kwargs):
        # if(obj):
        #     from datetime import datetime
        #
        #     print(type(obj.start_date))
        #
        #     d = datetime.strptime(str(obj.start_date), '%Y-%m-%d %H:%M:%S')
        #     print(type(d))
        #     obj.start_date = d.strftime("%d-%m-%Y %H:%M:%S")
        #     #print(obj.start_date.strftime("%d-%m-%Y %H:%M:%S"))
        #     print(type(obj.start_date))
        form = super().get_form(request, obj, **kwargs)
        fieldlist = ['course', 'trainer', 'branch']
        for fld in fieldlist:
            form.base_fields[fld].widget.can_change_related = False
            form.base_fields[fld].widget.can_add_related = False
            form.base_fields[fld].widget.can_view_related = False

        #form.base_fields["start_date"].widget.input_formats = ("%d-%m-%Y %H:%M:%S",)

        return form

    # def formfield_for_foreignkey(self, db_field, request, **kwargs):
    #     if db_field.name == "course":
    #         kwargs["queryset"] = Course.objects.filter(isactive=True)
    #     elif db_field.name == "trainer":
    #         kwargs["queryset"] = User.objects.filter(is_active=True, groups__name='Faculty')
    #     return super().formfield_for_foreignkey(db_field, request, **kwargs)


    def save_model(self, request, obj, form, change):

        # batchname = f"{obj.start_date.strftime('%d')}_{obj.start_date.strftime('%b')}_{obj.course.coursecode}_{obj.trainer}_{obj.branch.branch_code}_{obj.start_date.strftime('%I')}:{obj.start_date.strftime('%M')}{obj.start_date.strftime('%p')}"
        batchname = f"{obj.start_date.strftime('%d')}_{obj.start_date.strftime('%b')}_{obj.course.coursecode}_{obj.trainer}_{obj.branch.branch_code}_{obj.start_time.hour}:{obj.start_time.minute}"
        obj.batch = batchname
        # obj.created_user = request.user
        # print(eval(self.__class__.__name__))
        super().save_model(request, obj, form, change)

        #print(change)

        # Code to add data to Batch Transfer
        if change == False:
            batchtransfer = BatchTransfer()
            batchtransfer.start_date = obj.start_date
            batchtransfer.end_date = obj.end_date
            batchtransfer.batch = obj
            batchtransfer.trainer = obj.trainer
            #batchtransfer.isactive = obj.isactive
            #batchtransfer.isclosed = obj.isclosed
            batchtransfer.created_user = request.user
            batchtransfer.save()

        # End of Code to add data to Batch Transfer


    # def has_delete_permission(self, request, obj=None):
    #     # Disable delete
    #     return False


class BatchTransferAdmin(TransactionAdmin):

    list_display = ['trainer', 'formatstart_date', 'formatend_date']
    #list_filter = ("isclosed", "isactive")
    #search_fields = ("batch__startswith"),

    #exclude = ['created_user', 'isclosed']

    form = BatchForm

    add_form_template = "admin/batchtransfer_form.html"
    change_form_template = "admin/batchtransfer_form.html"

    batch_id = 0
    course_id = 0
    start_date_prefill = ""
    end_date_prefill = ""
    #fkey = True

    def add_view(self, request, form_url='', extra_context=None):

        global batch_id, course_id, start_date_prefill, end_date_prefill
        batch_id = request.GET.get('_changelist_filters')
        print(batch_id)
        if batch_id != None:
            batch_id = batch_id.split("=")[1]
            print(batch_id)
            batchname = Batch.objects.get(id=batch_id)
            course_id = batchname.course.id
            batchtransfer = BatchTransfer.objects.filter(batch_id=batch_id).order_by('-created_date')[:1][0]
            start_date_prefill = batchtransfer.start_date
            end_date_prefill = batchtransfer.end_date

            print(batchtransfer)
            # g = request.GET.copy()
            # g.update({
            #     'title': batchname,
            #     'contents': batchtransfer.trainer,
            # })
            # request.GET = g

        #     source = FeedPost.objects.get(id=source_id)
        #     # any extra processing can go here...
        #     g = request.GET.copy()
        #     g.update({
        #         'title': source.title,
        #         'contents': source.description + u"... \n\n[" + source.url + "]",
        #     })
        #
        #     request.GET = g

        extra_context = {'title': f'Transfer of {batchname}.'}

        return super(BatchTransferAdmin, self).add_view(request, form_url, extra_context)


    def get_form(self, request, obj=None, **kwargs):
        global batch_id, course_id, start_date_prefill, end_date_prefill
        # if(obj):
        #     from datetime import datetime
        #
        #     print(type(obj.start_date))
        #
        #     d = datetime.strptime(str(obj.start_date), '%Y-%m-%d %H:%M:%S')
        #     print(type(d))
        #     obj.start_date = d.strftime("%d-%m-%Y %H:%M:%S")
        #     #print(obj.start_date.strftime("%d-%m-%Y %H:%M:%S"))
        #     print(type(obj.start_date))
        form = super().get_form(request, obj, **kwargs)
        fieldlist = ['trainer', 'batch']
        for fld in fieldlist:
            form.base_fields[fld].widget.can_change_related = False
            form.base_fields[fld].widget.can_add_related = False
            form.base_fields[fld].widget.can_view_related = False

        if (obj == None):
            #form.base_fields['batch'].disabled = True
            #form.base_fields['trainer'].initial = 1
            form.base_fields['coursehiddenid'].initial = course_id
            form.base_fields['start_date'].initial = start_date_prefill
            form.base_fields['end_date'].initial = end_date_prefill

        #form.base_fields["start_date"].widget.input_formats = ("%d-%m-%Y %H:%M:%S",)

        return form



    # Code to change the title in change list
    def changelist_view(self, request, extra_context=None):
        batchid = request.GET.get("batch")
        if (batchid):
            # coursename = Course.objects.filter(id=courseid).values()[0].get("course")
            batchname = Batch.objects.get(id=batchid)
            # print(coursename)
            extra_context = {'title': f'Transfer of {batchname}.'}

        return super(BatchTransferAdmin, self).changelist_view(request, extra_context=extra_context)

    def formatstart_date(self, obj):
        return obj.start_date.strftime("%d-%m-%Y %I:%M%p")

    formatstart_date.short_description = 'Start Date'

    def formatend_date(self, obj):
        return obj.end_date.strftime("%d-%m-%Y")

    formatend_date.short_description = 'End Date'



    # def formfield_for_foreignkey(self, db_field, request, **kwargs):
    #
    #     #global fkey
    #     #if fkey == True:
    #     # print(db_field.name)
    #     # print(batch_id)
    #      #fkey = False
    #     if db_field.name == "trainer":
    #         #result = list(Course.objects.get(id=int(id)).trainers.values("id", "username"))
    #         kwargs["queryset"] = User.objects.filter(is_active=True, groups__name='Faculty')
    #         return super().formfield_for_foreignkey(db_field, request, **kwargs)


    def save_model(self, request, obj, form, change):

        # batchname = f"{obj.start_date.strftime('%d')}_{obj.start_date.strftime('%b')}_{obj.course.coursecode}_{obj.trainer}_{obj.trainer.userprofile.branch.branch_code}_{obj.start_date.strftime('%I')}:{obj.start_date.strftime('%M')}{obj.start_date.strftime('%p')}"
        # obj.batch = batchname

        super().save_model(request, obj, form, change)

    # def has_delete_permission(self, request, obj=None):
    #     # Disable delete
    #     return False




# https://stackoverflow.com/questions/877723/inline-form-validation-in-django
class UserProfileInlineFormset(forms.models.BaseInlineFormSet):
    def clean(self):
        # get forms that actually have valid data
        count = 0
        for form in self.forms:
            try:
                if form.cleaned_data:
                    count += 1
            except AttributeError:
                # annoyingly, if a subform is invalid Django explicity raises
                # an AttributeError for cleaned_data
                pass
        if count < 1:
            raise forms.ValidationError('You must have at least one user profile')

class UserProfileInline(admin.StackedInline):
    #formset = StudentCallStatusInlineFormset
    formset = UserProfileInlineFormset
    model = UserProfile
    fields = ('branch', 'mobile', 'status')
    #readonly_fields = ('added_date',)
    extra = 1 # only one record should be listed for adding initially
    max_num = 1 # the user should not be able to add more than one record
    can_delete = False # remove the delete option
    verbose_name = "User Profile"

    def __str__(self):
        return str(self.branch)


class MyUserAdmin(UserAdmin):

    #print(UserAdmin.fieldsets)
    inlines = (UserProfileInline,)
    list_display = ['username', 'first_name', 'last_name', 'get_branch', 'view_permission_link', 'email', 'is_staff']
    list_filter = ("userprofile__branch",)
    fieldsets = (
        (None,{'fields': ('username', 'password')}),
        ('Personal info', {'fields': (('first_name', 'last_name'), 'email')}),
        ('Permissions 1', {'fields': ('is_active', 'is_staff', 'is_superuser')}),
        ('Permissions 2', {'fields': ('groups',)}),
        ('Permissions 3', {'fields': ('user_permissions',)}),
        ('Important dates', {'fields': ('last_login', 'date_joined')})
        )

    def save_model(self, request, obj, form, change):



        super().save_model(request, obj, form, change)
        #print(obj.pk)

        if( UserDataPermission.objects.filter(user_id=obj.pk).count() == 0 ):
            from django.db import connection
            with connection.cursor() as cursor:
                cursor.execute("insert into AdminApp_userdatapermission (user_id,user_permission_id,is_permitted,created_date,created_user_id) values (%s, %s, True, now(), 1);", [obj.pk, obj.pk])
                cursor.execute("insert into AdminApp_userdatapermission (user_id,user_permission_id,is_permitted,created_date,created_user_id) select %s, U.id, False, now(), 1 from auth_user U inner join auth_user_groups UG on U.id = UG.user_id inner join auth_group G on G.id = UG.group_id where G.name <> 'Students';", [obj.pk])
                cursor.execute("insert into AdminApp_userdatapermission (user_id,user_permission_id,is_permitted,created_date,created_user_id) select U.id, %s, False, now(), 1 from auth_user U inner join auth_user_groups UG on U.id = UG.user_id inner join auth_group G on G.id = UG.group_id where G.name <> 'Students';", [obj.pk])




    #
    #SELECT * FROM trackerjetdb.auth_user;
    # insert into trackerjetdb.adminapp_userdatapermission(user_id, user_permission_id, is_permitted, created_date, created_user_id)
    # select
    # 1, U.id, False, now(), 1
    # from trackerjetdb.auth_user U
    # inner
    # join
    # trackerjetdb.auth_user_groups
    # UG
    # on
    # U.id = UG.user_id
    # inner
    # join
    # trackerjetdb.auth_group
    # G
    # on
    # G.id = UG.group_id
    # where
    # G.name <> "Students";
    #
    # insert
    # into
    # trackerjetdb.adminapp_userdatapermission(user_id, user_permission_id, is_permitted, created_date, created_user_id)
    # select
    # U.id, 1, False, now(), 1
    # from trackerjetdb.auth_user U
    # inner
    # join
    # trackerjetdb.auth_user_groups
    # UG
    # on
    # U.id = UG.user_id
    # inner
    # join
    # trackerjetdb.auth_group
    # G
    # on
    # G.id = UG.group_id
    # where
    # G.name <> "Students"

    def view_permission_link(self, obj):
        #count = obj.coursefees_set.count()
        url = (
                reverse("admin:AdminApp_userdatapermission_changelist")
                + "?"
                + urlencode({"user": f"{obj.id}"})
        )
        # print(url)
        return format_html('<a href="{}">Go</a>', url)

    view_permission_link.allow_tags = True
    view_permission_link.short_description = "User Data Selection"
    def has_delete_permission(self, request, obj=None):
        # Disable delete
        return False

    def get_branch(self, obj):
        return obj.userprofile.branch

    #get_branch.admin_order_field = 'author'  # Allows column order sorting
    get_branch.short_description = 'Branch'  # Renames column head
    class Media:
        js = ('admin/js/jquery.init.js', 'list_filter_collapse.js')


    #     (
    #     (None, {
    #         'fields': ('url', 'title', 'content', 'sites')
    #     }),
    #     ('Advanced options', {
    #         'classes': ('collapse',),
    #         'fields': ('enable_comments', 'registration_required', 'template_name')
    #     }),
    # )

    # fieldsets = UserAdmin.fieldsets + (
    #         (None, {'fields': ('some_extra_data',)}),
    # )


class MyGroupAdmin(GroupAdmin):
    #print(GroupAdmin.fieldsets)
    def has_delete_permission(self, request, obj=None):
        # Disable delete
        return False


# To hide Authentication & Authorization section
admin.site.register(User, MyUserAdmin)
admin.site.register(Group, MyGroupAdmin)

class CourseSyllabusImportExport(TransactionAdmin, ImportExportModelAdmin):
    resource_class = CourseSyllabusResource
    list_display = ['id','day', 'syllabus', 'percentage']
    list_editable = ['day', 'syllabus', 'percentage']

    #list_filter = ("course",)
    search_fields = ("course__course__startswith",)

    form = CourseAdminForm

    add_form_template = "admin/common_form.html"
    change_form_template = "admin/common_form.html"


    def has_module_permission(self, request):
        return False

    # Code to change the title in change list
    def changelist_view(self, request, extra_context=None):
        courseid = request.GET.get("course")
        if (courseid):
            # coursename = Course.objects.filter(id=courseid).values()[0].get("course")
            coursename = Course.objects.get(id=courseid)
            # print(coursename)
            extra_context = {'title': f'Course syllabus of {coursename}.'}

        return super(CourseSyllabusImportExport, self).changelist_view(request, extra_context=extra_context)

    def get_form(self, request, obj=None, **kwargs):
        form = super().get_form(request, obj, **kwargs)
        fieldlist = ['course', 'syllabus']
        for fld in fieldlist:
            form.base_fields[fld].widget.can_change_related = False
            form.base_fields[fld].widget.can_add_related = False
            form.base_fields[fld].widget.can_view_related = False
        return form



    # def formfield_for_foreignkey(self, db_field, request, **kwargs):
    #     if db_field.name == "course":
    #         kwargs["queryset"] = Course.objects.filter(isactive=True)
    #     elif db_field.name == "syllabus":
    #         kwargs["queryset"] = Syllabus.objects.filter(isactive=True)
    #     elif db_field.name == "day":
    #         kwargs["queryset"] = MasterData.objects.filter(type="Day", isactive=True)
    #     return super().formfield_for_foreignkey(db_field, request, **kwargs)


class UserDataPermissionAdmin(TransactionAdmin):
    list_display = ('user_permission', 'is_permitted')
    list_editable = ('is_permitted',)

    def has_add_permission(self, request):
        # Disable delete
        return False

    def has_module_permission(self, request):
        return False
    # Code to change the title in change list
    def changelist_view(self, request, extra_context=None):
        userid = request.GET.get("user")
        if (userid):
            # coursename = Course.objects.filter(id=courseid).values()[0].get("course")
            username = User.objects.get(id=userid)
            # print(coursename)
            extra_context = {'title': f'User Data selection/permission of {username}.'}

        return super(UserDataPermissionAdmin, self).changelist_view(request, extra_context=extra_context)


# Register your models here.
# AdminApp(Settings) models
admin.site.register(State, StateAdmin)
admin.site.register(District, DistrictAdmin)
admin.site.register(Qualification, QualificationAdmin)
admin.site.register(EnquirySource, EnquirySourceAdmin)
admin.site.register(Branch, BranchAdmin)
admin.site.register(FollowUpStatus, FollowUpStatusAdmin)
admin.site.register(Company, CompanyAdmin)
admin.site.register(MasterData, MasterDataAdmin)
admin.site.register(Batch, BatchAdmin)
admin.site.register(BatchTransfer, BatchTransferAdmin)
admin.site.register(Syllabus, SyllabusAdmin)
admin.site.register(Course, CourseAdmin)
admin.site.register(CourseFees, CourseFeesAdmin)
admin.site.register(CourseSyllabus, CourseSyllabusImportExport)
admin.site.register(UserDataPermission, UserDataPermissionAdmin)
#admin.site.register(CourseSyllabusImportExport)






# my_admin_site = TrackerJetAdminSite()
# my_admin_site.register(State, StateAdmin)
# my_admin_site.register(District, DistrictAdmin)
# my_admin_site.register(Qualification, QualificationAdmin)
# my_admin_site.register(EnquirySource, EnquirySourceAdmin)
# my_admin_site.register(Branch, BranchAdmin)
# my_admin_site.register(FollowUpStatus, FollowUpStatusAdmin)

