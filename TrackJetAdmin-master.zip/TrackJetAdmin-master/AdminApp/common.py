from django.contrib.auth.models import User, Group
from django.db import IntegrityError, transaction

from AdminApp.models import UserProfile


def create_student_user(studentname, email, branch, phone):

    try:
        with transaction.atomic():
            username = studentname.replace(" ", "_")
            user = User.objects.create_user(username=username,
                                            email=email,
                                            password=f"{username}@oneteam", is_staff=True)
            userprofile = UserProfile()
            userprofile.user = user
            userprofile.branch = branch
            userprofile.mobile = phone
            userprofile.status = "Working"
            userprofile.save()
            group = Group.objects.get(name="Student")
            user.groups.add(group)
            return user
    except IntegrityError:

        user = User.objects.create_user(username=f"{studentname.replace(' ', '_')}_1",
                                        email=email,
                                        password=f"{studentname}@oneteam", is_staff=True)
        userprofile = UserProfile()
        userprofile.user = user
        userprofile.branch = branch
        userprofile.mobile = phone
        userprofile.status = "Working"
        userprofile.save()
        group = Group.objects.get(name="Student")
        user.groups.add(group)
        return user
    except:
        pass




